MUSA LAUNCHER - yadda ake samun APK

1. Ka bude GitHub (github.com) ka kirkiri sabon repository (New repository).
2. Ka daura DUKKAN fayilolin da ke cikin wannan zip a cikin repository din
   (har da folder din .github - shi ke gina APK).
   Idan kana waya kuma .github bai daura ba: ka danna "Add file > Create new file",
   ka rubuta sunan:  .github/workflows/build.yml  ka kwafa abin da ke cikin fayil din.
3. Ka danna tab din "Actions" - za a fara gina APK kai tsaye (minti 3-6).
4. Idan ya gama, ka bude aikin da ya yi nasara, ka sauke "musa-launcher-apk" daga Artifacts.
   Zai zo a zip - ka fitar da app-debug.apk ka saka a waya.
5. Bayan ka saka shi: Settings > Apps > Default apps > Home app > Musa Launcher.

Yadda ake amfani:
- Ja sama a allon gida = jerin manhajoji
- Danna ka rike a allon gida = canza wallpaper
- Danna ka rike manhaja a jeri = saka ta a dock
- Danna ka rike manhaja a dock = cire ta
