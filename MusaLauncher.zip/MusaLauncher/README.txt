MUSA LAUNCHER 3.0

NEW IN THIS VERSION
- Everything in the app is now in English
- Home screen quick buttons: "Hon. Musa" (About), "Music" and "Developer" (About)
- Music player with background playback and notification controls
- Weather, prayer times, battery, folders, hidden/locked apps, wallpaper slideshow (from 2.0)

ADDING THE 6 SONGS
1. In your GitHub repository open: MusaLauncher/app/src/main/assets/songs
2. Tap Add file > Upload files and pick your .mp3 files (each file must be under 25 MB).
3. The file name becomes the song title. Start names with numbers to set the order,
   e.g. "01 - Mafara Alkairi Ne.mp3".
Songs can also be added from the phone inside the music player (button at the bottom).

EDITING THE ABOUT PAGES
Edit these text files on GitHub (pencil icon) and commit:
- app/src/main/assets/about_musa.txt   (About Hon. Musa)
- app/src/main/assets/about_dev.txt    (About the developer/launcher)
Each section starts with a line like:  ## Title

BUILDING THE APK
1. Upload this MusaLauncher.zip to your repository (same name replaces the old one) and commit.
2. Open the Actions tab and wait for the green check (3-6 minutes).
3. Download "musa-launcher-apk" from Artifacts and unzip app-debug.apk.
4. Install it over the old version (the signing key is now fixed, so updates install normally;
   if the phone refuses, uninstall the previous version once and install again).
