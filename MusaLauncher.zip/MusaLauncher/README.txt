MUSA LAUNCHER 2.0

SABUWA A WANNAN VERSION:
- Shafuka (ja gefe) da folders
- Widgets: yanayi, lokutan sallah, baturi, widget na hotunan kamfen
- Ja sama = jerin manhajoji | ja kasa = notification
- Taba sau biyu = kulle waya (sai ka kunna a Saituna > Kulle waya)
- Danna ka rike allon gida = wallpaper / widgets / saituna
- Wallpaper slideshow + zabar hoto daga gallery
- Boye manhajoji da kulle su da PIN
- Saituna: siffar icon, launi, duhu/haske, girman icon

YADDA AKE SAMUN APK:
1. A repository dinka na GitHub, ka daura wannan MusaLauncher.zip (da sunan MusaLauncher.zip
   iri daya da na baya, zai maye gurbinsa). Ka danna Commit changes.
2. Ka bude tab din Actions, ka jira gina APK (minti 3-6).
3. Ka sauke "musa-launcher-apk" daga Artifacts, ka fitar da app-debug.apk.
4. KA CIRE tsohon Musa Launcher daga wayarka kafin ka saka sabon (sa hannun APK ya canza).
   Wannan sau daya ne kawai - nan gaba sabuntawa za su shiga kai tsaye.
5. Ka saka sabon APK, sannan Settings > Apps > Default apps > Home app > Musa Launcher.
