package com.musa.launcher

import java.net.HttpURLConnection
import java.net.URL

object Net {
    fun get(url: String): String? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 8000
            val s = c.inputStream.bufferedReader().use { r -> r.readText() }
            c.disconnect()
            s
        } catch (e: Exception) {
            null
        }
    }
}
