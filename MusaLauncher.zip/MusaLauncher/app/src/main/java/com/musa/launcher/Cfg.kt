package com.musa.launcher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

class HomeEntry(var folder: String?, val pkgs: MutableList<String>)

class Cfg(ctx: Context) {
    private val p: SharedPreferences = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    private fun getI(k: String, d: Int): Int = p.getInt(k, d)
    private fun putI(k: String, v: Int) { p.edit().putInt(k, v).apply() }
    private fun getB(k: String, d: Boolean): Boolean = p.getBoolean(k, d)
    private fun putB(k: String, v: Boolean) { p.edit().putBoolean(k, v).apply() }
    private fun getS(k: String): String = p.getString(k, "") ?: ""
    private fun putS(k: String, v: String) { p.edit().putString(k, v).apply() }
    private fun getL(k: String): Long = p.getLong(k, 0L)
    private fun putL(k: String, v: Long) { p.edit().putLong(k, v).apply() }

    private fun csvGet(k: String): MutableList<String> {
        val s = getS(k)
        return if (s.isEmpty()) mutableListOf() else s.split(",").toMutableList()
    }

    private fun csvPut(k: String, v: List<String>) {
        putS(k, v.joinToString(","))
    }

    var wallpaper: Int
        get() = getI("wallpaper", 0)
        set(v) { putI("wallpaper", v) }

    var shape: Int
        get() = getI("shape", 0)
        set(v) { putI("shape", v) }

    var accent: Int
        get() = getI("accent", Color.parseColor("#29B6F6"))
        set(v) { putI("accent", v) }

    var dark: Boolean
        get() = getB("dark", true)
        set(v) { putB("dark", v) }

    var iconSize: Int
        get() = getI("iconSize", 1)
        set(v) { putI("iconSize", v) }

    var labels: Boolean
        get() = getB("labels", true)
        set(v) { putB("labels", v) }

    var slideshow: Int
        get() = getI("slideshow", 0)
        set(v) { putI("slideshow", v) }

    var lastSlide: Long
        get() = getL("lastSlide")
        set(v) { putL("lastSlide", v) }

    var showWeather: Boolean
        get() = getB("showWeather", true)
        set(v) { putB("showWeather", v) }

    var showPrayer: Boolean
        get() = getB("showPrayer", true)
        set(v) { putB("showPrayer", v) }

    var showBattery: Boolean
        get() = getB("showBattery", true)
        set(v) { putB("showBattery", v) }

    var showCampaign: Boolean
        get() = getB("showCampaign", true)
        set(v) { putB("showCampaign", v) }

    var city: String
        get() = getS("city")
        set(v) { putS("city", v) }

    var lat: String
        get() = getS("lat")
        set(v) { putS("lat", v) }

    var lon: String
        get() = getS("lon")
        set(v) { putS("lon", v) }

    var weatherCache: String
        get() = getS("weatherCache")
        set(v) { putS("weatherCache", v) }

    var weatherTime: Long
        get() = getL("weatherTime")
        set(v) { putL("weatherTime", v) }

    var prayerCache: String
        get() = getS("prayerCache")
        set(v) { putS("prayerCache", v) }

    var prayerDate: String
        get() = getS("prayerDate")
        set(v) { putS("prayerDate", v) }

    var pinHash: String
        get() = getS("pinHash")
        set(v) { putS("pinHash", v) }

    var hidden: MutableList<String>
        get() = csvGet("hidden")
        set(v) { csvPut("hidden", v) }

    var locked: MutableList<String>
        get() = csvGet("locked")
        set(v) { csvPut("locked", v) }

    var dock: MutableList<String>
        get() = csvGet("dock")
        set(v) { csvPut("dock", v) }

    var customWps: MutableList<String>
        get() = csvGet("customWps")
        set(v) { csvPut("customWps", v) }

    // ---- PIN

    private fun hash(pin: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(("musa-launcher:" + pin).toByteArray())
        return d.joinToString("") { b -> "%02x".format(b) }
    }

    fun hasPin(): Boolean = pinHash.isNotEmpty()

    fun checkPin(pin: String): Boolean = hash(pin) == pinHash

    fun setPin(pin: String) {
        pinHash = hash(pin)
    }

    // ---- Custom songs (added from the phone)

    fun loadSongs(): MutableList<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        try {
            val arr = JSONArray(p.getString("songs", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Pair(o.getString("u"), o.getString("t")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun saveSongs(list: List<Pair<String, String>>) {
        val arr = JSONArray()
        for (s in list) {
            val o = JSONObject()
            o.put("u", s.first)
            o.put("t", s.second)
            arr.put(o)
        }
        p.edit().putString("songs", arr.toString()).apply()
    }

    // ---- Home screen items

    fun loadHome(): MutableList<HomeEntry> {
        val out = mutableListOf<HomeEntry>()
        try {
            val arr = JSONArray(p.getString("home", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val folder: String? = if (o.has("f")) o.getString("f") else null
                val ps = o.getJSONArray("p")
                val list = mutableListOf<String>()
                for (j in 0 until ps.length()) list.add(ps.getString(j))
                out.add(HomeEntry(folder, list))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun saveHome(list: List<HomeEntry>) {
        val arr = JSONArray()
        for (e in list) {
            val o = JSONObject()
            val f = e.folder
            if (f != null) o.put("f", f)
            val ps = JSONArray()
            for (s in e.pkgs) ps.put(s)
            o.put("p", ps)
            arr.put(o)
        }
        p.edit().putString("home", arr.toString()).apply()
    }
}
