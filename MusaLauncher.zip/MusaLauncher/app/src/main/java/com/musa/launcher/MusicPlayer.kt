package com.musa.launcher

import android.content.Context
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.PowerManager

class Track(val title: String, val asset: String?, val uri: String?)

object MusicPlayer {
    val tracks = mutableListOf<Track>()
    var index = 0
    var shuffle = false
    var repeatOne = false

    private var mp: MediaPlayer? = null
    private var appCtx: Context? = null
    private val listeners = mutableListOf<() -> Unit>()

    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            try {
                if (mp?.isPlaying == true) {
                    mp?.pause()
                    changed()
                }
            } catch (e: Exception) {
            }
        }
    }

    fun addListener(l: () -> Unit) {
        if (!listeners.contains(l)) listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    fun changed() {
        for (l in listeners.toList()) l()
    }

    private fun isAudio(n: String): Boolean {
        val l = n.lowercase()
        return l.endsWith(".mp3") || l.endsWith(".m4a") || l.endsWith(".ogg") ||
            l.endsWith(".wav") || l.endsWith(".aac")
    }

    private fun prettyTitle(n: String): String {
        val base = n.substringBeforeLast('.').replace('_', ' ').trim()
        val stripped = base.replace(Regex("^\\d+\\s*[-._)]*\\s*"), "").trim()
        return if (stripped.isEmpty()) base else stripped
    }

    fun init(ctx: Context, custom: List<Pair<String, String>>) {
        appCtx = ctx.applicationContext
        tracks.clear()
        try {
            val names = ctx.assets.list("songs")
            if (names != null) {
                for (n in names.filter { x -> isAudio(x) }.sorted()) {
                    tracks.add(Track(prettyTitle(n), "songs/" + n, null))
                }
            }
        } catch (e: Exception) {
        }
        for (c in custom) tracks.add(Track(c.second, null, c.first))
        if (index >= tracks.size) index = 0
    }

    fun current(): Track? = if (index in tracks.indices) tracks[index] else null

    fun isPlaying(): Boolean {
        return try {
            mp?.isPlaying == true
        } catch (e: Exception) {
            false
        }
    }

    fun position(): Int {
        return try {
            mp?.currentPosition ?: 0
        } catch (e: Exception) {
            0
        }
    }

    fun duration(): Int {
        return try {
            mp?.duration ?: 0
        } catch (e: Exception) {
            0
        }
    }

    fun seek(ms: Int) {
        try {
            mp?.seekTo(ms)
        } catch (e: Exception) {
        }
    }

    private fun release() {
        try {
            mp?.release()
        } catch (e: Exception) {
        }
        mp = null
    }

    private fun requestFocus() {
        val am = appCtx?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        am?.requestAudioFocus(focusListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
    }

    private fun prepare(i: Int): Boolean {
        val ctx = appCtx ?: return false
        if (i !in tracks.indices) return false
        release()
        index = i
        val t = tracks[i]
        return try {
            val p = MediaPlayer()
            val a = t.asset
            val u = t.uri
            if (a != null) {
                val afd = ctx.assets.openFd(a)
                p.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
            } else if (u != null) {
                p.setDataSource(ctx, Uri.parse(u))
            }
            p.setWakeMode(ctx, PowerManager.PARTIAL_WAKE_LOCK)
            p.setOnCompletionListener { onDone() }
            p.setOnErrorListener { _, _, _ -> true }
            p.prepare()
            mp = p
            true
        } catch (e: Exception) {
            mp = null
            false
        }
    }

    fun play(i: Int) {
        if (prepare(i)) {
            requestFocus()
            try {
                mp?.start()
            } catch (e: Exception) {
            }
        }
        changed()
    }

    fun toggle() {
        val p = mp
        if (p == null) {
            if (tracks.isNotEmpty()) play(index)
            return
        }
        try {
            if (p.isPlaying) {
                p.pause()
            } else {
                requestFocus()
                p.start()
            }
        } catch (e: Exception) {
        }
        changed()
    }

    private fun randomOther(): Int {
        var n = index
        while (n == index) n = (0 until tracks.size).random()
        return n
    }

    fun next() {
        if (tracks.isEmpty()) return
        val n = if (shuffle && tracks.size > 1) randomOther() else (index + 1) % tracks.size
        play(n)
    }

    fun prev() {
        if (tracks.isEmpty()) return
        if (mp != null && position() > 3000) {
            seek(0)
            changed()
            return
        }
        play((index - 1 + tracks.size) % tracks.size)
    }

    private fun onDone() {
        if (repeatOne) play(index) else next()
    }

    fun stop() {
        release()
        try {
            val am = appCtx?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            am?.abandonAudioFocus(focusListener)
        } catch (e: Exception) {
        }
        changed()
    }
}
