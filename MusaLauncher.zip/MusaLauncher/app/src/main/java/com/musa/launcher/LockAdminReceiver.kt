package com.musa.launcher

import android.app.admin.DeviceAdminReceiver

class LockAdminReceiver : DeviceAdminReceiver()
