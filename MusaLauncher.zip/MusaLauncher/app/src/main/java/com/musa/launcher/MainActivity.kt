package com.musa.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class AppItem(
    val label: String,
    val pkg: String,
    val activity: String,
    val icon: Drawable
)

class MainActivity : Activity() {

    private val wallpaperRes = intArrayOf(R.drawable.wp1, R.drawable.wp2, R.drawable.wp3, R.drawable.wp4)
    private val drawerBgIndex = 2 // wp3 is used behind the app drawer

    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var wallpaperView: ImageView
    private lateinit var homeLayer: LinearLayout
    private lateinit var dockRow: LinearLayout
    private lateinit var drawerLayer: LinearLayout
    private lateinit var drawerBg: ImageView
    private lateinit var drawerShade: View
    private lateinit var drawerRoot: FrameLayout
    private lateinit var searchBox: EditText
    private lateinit var grid: GridView
    private lateinit var adapter: AppAdapter

    private var allApps: List<AppItem> = emptyList()
    private var drawerOpen = false
    private val handler = Handler(Looper.getMainLooper())

    private var downX = 0f
    private var downY = 0f
    private var longPressed = false
    private val longPressRunnable = Runnable {
        longPressed = true
        showWallpaperPicker()
    }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshApps()
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        buildUi()
        setWallpaper(prefs.getInt("wallpaper", 0))
        refreshApps()

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(packageReceiver, f, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(packageReceiver, f)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(packageReceiver)
        } catch (e: Exception) {
        }
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        // Wallpaper
        wallpaperView = ImageView(this)
        wallpaperView.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(wallpaperView, FrameLayout.LayoutParams(-1, -1))

        // Soft shade so the clock and dock stay readable
        val shade = View(this)
        shade.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(90, 0, 0, 0), Color.argb(0, 0, 0, 0), Color.argb(110, 0, 0, 0))
        )
        root.addView(shade, FrameLayout.LayoutParams(-1, -1))

        // Home layer: clock on top, dock at bottom
        homeLayer = LinearLayout(this)
        homeLayer.orientation = LinearLayout.VERTICAL
        homeLayer.gravity = Gravity.CENTER_HORIZONTAL

        val clock = TextClock(this)
        clock.format12Hour = "h:mm"
        clock.format24Hour = "HH:mm"
        clock.textSize = 58f
        clock.setTextColor(Color.WHITE)
        clock.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        clock.setShadowLayer(10f, 0f, 2f, Color.argb(160, 0, 0, 0))
        clock.gravity = Gravity.CENTER
        homeLayer.addView(clock, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(36) })

        val date = TextClock(this)
        date.format12Hour = "EEEE, d MMMM"
        date.format24Hour = "EEEE, d MMMM"
        date.textSize = 16f
        date.setTextColor(Color.WHITE)
        date.setShadowLayer(8f, 0f, 2f, Color.argb(160, 0, 0, 0))
        homeLayer.addView(date, LinearLayout.LayoutParams(-2, -2))

        val spacer = View(this)
        homeLayer.addView(spacer, LinearLayout.LayoutParams(-1, 0, 1f))

        val hint = TextView(this)
        hint.text = "\u2303"
        hint.textSize = 18f
        hint.setTextColor(Color.argb(200, 255, 255, 255))
        hint.gravity = Gravity.CENTER
        homeLayer.addView(hint, LinearLayout.LayoutParams(-2, -2))

        dockRow = LinearLayout(this)
        dockRow.orientation = LinearLayout.HORIZONTAL
        dockRow.gravity = Gravity.CENTER
        dockRow.setPadding(dp(14), dp(12), dp(14), dp(12))
        dockRow.background = GradientDrawable().apply {
            setColor(Color.argb(80, 255, 255, 255))
            cornerRadius = dp(30).toFloat()
        }
        homeLayer.addView(
            dockRow,
            LinearLayout.LayoutParams(-2, -2).apply {
                bottomMargin = dp(16)
                topMargin = dp(6)
            }
        )

        homeLayer.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.x
                    downY = e.y
                    longPressed = false
                    handler.postDelayed(longPressRunnable, 600)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.y - downY) > dp(12) || abs(e.x - downX) > dp(12)) {
                        handler.removeCallbacks(longPressRunnable)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longPressRunnable)
                    if (!longPressed && downY - e.y > dp(80)) openDrawer()
                }
                MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longPressRunnable)
            }
            true
        }
        root.addView(homeLayer, FrameLayout.LayoutParams(-1, -1))

        // Drawer layer
        drawerRoot = FrameLayout(this)
        drawerRoot.visibility = View.GONE

        drawerBg = ImageView(this)
        drawerBg.scaleType = ImageView.ScaleType.CENTER_CROP
        drawerRoot.addView(drawerBg, FrameLayout.LayoutParams(-1, -1))

        drawerShade = View(this)
        drawerShade.setBackgroundColor(Color.argb(200, 0, 0, 0))
        drawerRoot.addView(drawerShade, FrameLayout.LayoutParams(-1, -1))

        drawerLayer = LinearLayout(this)
        drawerLayer.orientation = LinearLayout.VERTICAL

        // Handle bar: tap or swipe down to close
        val handleBox = FrameLayout(this)
        val handleBar = View(this)
        handleBar.background = GradientDrawable().apply {
            setColor(Color.argb(150, 255, 255, 255))
            cornerRadius = dp(3).toFloat()
        }
        handleBox.addView(
            handleBar,
            FrameLayout.LayoutParams(dp(44), dp(5)).apply {
                gravity = Gravity.CENTER
            }
        )
        var hy = 0f
        handleBox.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> hy = e.y
                MotionEvent.ACTION_UP -> if (e.y - hy > dp(30) || abs(e.y - hy) < dp(6)) closeDrawer()
            }
            true
        }
        drawerLayer.addView(handleBox, LinearLayout.LayoutParams(-1, dp(36)))

        searchBox = EditText(this)
        searchBox.hint = "Bincika manhaja..."
        searchBox.setHintTextColor(Color.argb(170, 255, 255, 255))
        searchBox.setTextColor(Color.WHITE)
        searchBox.textSize = 16f
        searchBox.setSingleLine(true)
        searchBox.inputType = InputType.TYPE_CLASS_TEXT
        searchBox.setPadding(dp(18), dp(10), dp(18), dp(10))
        searchBox.background = GradientDrawable().apply {
            setColor(Color.argb(70, 255, 255, 255))
            cornerRadius = dp(22).toFloat()
        }
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterApps(s?.toString() ?: "")
            }
        })
        drawerLayer.addView(
            searchBox,
            LinearLayout.LayoutParams(-1, -2).apply {
                leftMargin = dp(18)
                rightMargin = dp(18)
                bottomMargin = dp(8)
            }
        )

        grid = GridView(this)
        grid.numColumns = 4
        grid.verticalSpacing = dp(6)
        grid.selector = GradientDrawable().apply { setColor(Color.TRANSPARENT) }
        grid.setPadding(dp(6), dp(6), dp(6), dp(6))
        grid.clipToPadding = false
        adapter = AppAdapter(emptyList())
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> launch(adapter.items[pos]) }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            pinToDock(adapter.items[pos])
            true
        }
        drawerLayer.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))

        drawerRoot.addView(drawerLayer, FrameLayout.LayoutParams(-1, -1))
        root.addView(drawerRoot, FrameLayout.LayoutParams(-1, -1))

        @Suppress("DEPRECATION")
        root.setOnApplyWindowInsetsListener { _, insets ->
            val top = insets.systemWindowInsetTop
            val bottom = insets.systemWindowInsetBottom
            homeLayer.setPadding(0, top, 0, bottom)
            drawerLayer.setPadding(0, top, 0, bottom)
            insets
        }

        setContentView(root)
    }

    // ------------------------------------------------------- wallpapers

    private fun decodeScaled(resId: Int, reqW: Int, reqH: Int): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeResource(resources, resId, o)
        var sample = 1
        while (o.outWidth / (sample * 2) >= reqW && o.outHeight / (sample * 2) >= reqH) {
            sample *= 2
        }
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        o2.inPreferredConfig = Bitmap.Config.RGB_565
        return BitmapFactory.decodeResource(resources, resId, o2)
    }

    private fun setWallpaper(index: Int) {
        val i = if (index in wallpaperRes.indices) index else 0
        val dm = resources.displayMetrics
        wallpaperView.setImageBitmap(decodeScaled(wallpaperRes[i], dm.widthPixels, dm.heightPixels))
        prefs.edit().putInt("wallpaper", i).apply()
    }

    private fun showWallpaperPicker() {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(12), dp(12), dp(12), dp(12))
        var dialog: AlertDialog? = null
        for (i in wallpaperRes.indices) {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(decodeScaled(wallpaperRes[i], dp(110), dp(190)))
            iv.outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(14).toFloat())
                }
            }
            iv.clipToOutline = true
            iv.setOnClickListener {
                setWallpaper(i)
                dialog?.dismiss()
            }
            row.addView(iv, LinearLayout.LayoutParams(dp(110), dp(190)).apply { rightMargin = dp(10) })
        }
        val scroll = HorizontalScrollView(this)
        scroll.addView(row)
        val d = AlertDialog.Builder(this)
            .setTitle("Zaɓi wallpaper")
            .setView(scroll)
            .setNegativeButton("Rufe", null)
            .create()
        dialog = d
        d.show()
    }

    // ------------------------------------------------------------- apps

    private fun refreshApps() {
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allApps = pm.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                AppItem(
                    it.loadLabel(pm).toString(),
                    it.activityInfo.packageName,
                    it.activityInfo.name,
                    it.loadIcon(pm)
                )
            }
            .sortedBy { it.label.lowercase() }
        filterApps(searchBox.text.toString())
        buildDock()
    }

    private fun filterApps(q: String) {
        val t = q.trim()
        adapter.items = if (t.isEmpty()) allApps else allApps.filter { it.label.contains(t, ignoreCase = true) }
        adapter.notifyDataSetChanged()
    }

    private fun launch(a: AppItem) {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(a.pkg, a.activity)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Ba a iya buɗe manhajar ba", Toast.LENGTH_SHORT).show()
        }
        if (drawerOpen) closeDrawer()
    }

    private fun roundIcon(size: Int, d: Drawable): ImageView {
        val iv = ImageView(this)
        iv.setImageDrawable(d)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, view.width * 0.24f)
            }
        }
        iv.clipToOutline = true
        iv.layoutParams = LinearLayout.LayoutParams(size, size)
        return iv
    }

    private inner class AppAdapter(var items: List<AppItem>) : BaseAdapter() {
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val item = items[position]
            val cell = LinearLayout(this@MainActivity)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(dp(2), dp(8), dp(2), dp(8))
            cell.addView(roundIcon(dp(54), item.icon))
            val tv = TextView(this@MainActivity)
            tv.text = item.label
            tv.setTextColor(Color.WHITE)
            tv.textSize = 11.5f
            tv.maxLines = 1
            tv.gravity = Gravity.CENTER
            tv.ellipsize = android.text.TextUtils.TruncateAt.END
            tv.setShadowLayer(4f, 0f, 1f, Color.BLACK)
            cell.addView(tv, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
            return cell
        }
    }

    // ------------------------------------------------------------- dock

    private fun defaultDock(): List<AppItem> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("http://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val result = mutableListOf<AppItem>()
        for (intent in intents) {
            val ri = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY) ?: continue
            val pkg = ri.activityInfo.packageName
            val app = allApps.firstOrNull { a -> a.pkg == pkg } ?: continue
            if (result.none { r -> r.pkg == app.pkg }) result.add(app)
        }
        return result
    }

    private fun dockApps(): List<AppItem> {
        val saved = prefs.getString("dock", null)
        if (saved.isNullOrEmpty()) return defaultDock()
        val list = saved.split(",").mapNotNull { pkg -> allApps.firstOrNull { a -> a.pkg == pkg } }
        return if (list.isEmpty()) defaultDock() else list
    }

    private fun buildDock() {
        dockRow.removeAllViews()
        for (a in dockApps()) {
            val iv = roundIcon(dp(58), a.icon)
            iv.setOnClickListener { launch(a) }
            iv.setOnLongClickListener {
                unpinFromDock(a)
                true
            }
            val lp = LinearLayout.LayoutParams(dp(58), dp(58))
            lp.leftMargin = dp(8)
            lp.rightMargin = dp(8)
            dockRow.addView(iv, lp)
        }
    }

    private fun pinToDock(a: AppItem) {
        val cur = dockApps().map { it.pkg }.toMutableList()
        if (cur.contains(a.pkg)) {
            Toast.makeText(this, "Tuni yana cikin dock", Toast.LENGTH_SHORT).show()
            return
        }
        cur.add(a.pkg)
        while (cur.size > 4) cur.removeAt(0)
        prefs.edit().putString("dock", cur.joinToString(",")).apply()
        buildDock()
        Toast.makeText(this, "An saka ${a.label} a dock", Toast.LENGTH_SHORT).show()
    }

    private fun unpinFromDock(a: AppItem) {
        val cur = dockApps().map { it.pkg }.toMutableList()
        cur.remove(a.pkg)
        prefs.edit().putString("dock", cur.joinToString(",")).apply()
        buildDock()
    }

    // ----------------------------------------------------------- drawer

    private fun openDrawer() {
        if (drawerOpen) return
        drawerOpen = true
        if (drawerBg.drawable == null) {
            val dm = resources.displayMetrics
            drawerBg.setImageBitmap(decodeScaled(wallpaperRes[drawerBgIndex], dm.widthPixels / 2, dm.heightPixels / 2))
        }
        drawerRoot.alpha = 0f
        drawerRoot.translationY = dp(60).toFloat()
        drawerRoot.visibility = View.VISIBLE
        drawerRoot.animate().alpha(1f).translationY(0f).setDuration(220).start()
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        searchBox.setText("")
        hideKeyboard()
        drawerRoot.animate().alpha(0f).translationY(dp(60).toFloat()).setDuration(180).withEndAction {
            drawerRoot.visibility = View.GONE
        }.start()
        grid.setSelection(0)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(root.windowToken, 0)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Pressing Home while the drawer is open closes it
        if (intent != null && intent.action == Intent.ACTION_MAIN && drawerOpen) closeDrawer()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (drawerOpen) closeDrawer()
        // On the home screen, Back does nothing (like a real launcher)
    }
}
