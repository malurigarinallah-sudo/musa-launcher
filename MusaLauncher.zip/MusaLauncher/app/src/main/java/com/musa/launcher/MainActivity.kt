package com.musa.launcher

import android.app.Activity
import android.Manifest
import android.app.AlertDialog
import android.app.Dialog
import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class AppItem(
    val label: String,
    val pkg: String,
    val activity: String,
    val icon: Drawable
)

class MainActivity : Activity() {

    companion object {
        const val REQ_PICK = 4711
        const val REQ_SONGS = 4712
    }

    private class Wp(val res: Int, val file: String?)

    private val builtinWp = intArrayOf(R.drawable.wp1, R.drawable.wp2, R.drawable.wp3, R.drawable.wp4)
    private val campaignRes = intArrayOf(R.drawable.cw1, R.drawable.cw2, R.drawable.cw3, R.drawable.cw4)
    private val campaignTags = arrayOf("Mafara Alkairi Ne", "Hope of the Peoples", "Fika East", "Mafara Alkairi Ne")
    private val campaignBmps = arrayOfNulls<Bitmap>(4)
    private var campaignIdx = 0

    private val accents = intArrayOf(
        Color.parseColor("#29B6F6"),
        Color.parseColor("#2ECC71"),
        Color.parseColor("#E53935"),
        Color.parseColor("#FFA726"),
        Color.parseColor("#EC407A"),
        Color.parseColor("#AB47BC")
    )
    private val accentNames = arrayOf("Blue", "Green", "Red", "Orange", "Pink", "Purple")

    private val cols = 4
    private val perPage = 20

    private lateinit var cfg: Cfg
    private lateinit var homeList: MutableList<HomeEntry>

    private lateinit var root: FrameLayout
    private lateinit var wallpaperView: ImageView
    private lateinit var homeLayer: LinearLayout
    private lateinit var pager: ViewPager
    private lateinit var dots: LinearLayout
    private lateinit var dockRow: LinearLayout
    private lateinit var drawerRoot: FrameLayout
    private lateinit var drawerBg: ImageView
    private lateinit var drawerShade: View
    private lateinit var drawerLayer: LinearLayout
    private lateinit var searchBox: EditText
    private lateinit var gear: TextView
    private lateinit var grid: GridView
    private lateinit var adapter: AppAdapter

    private var allApps: List<AppItem> = emptyList()
    private var visibleApps: List<AppItem> = emptyList()
    private var drawerOpen = false
    private val handler = Handler(Looper.getMainLooper())

    // widget references (rebuilt with the widget page)
    private var batteryPct: TextView? = null
    private var batteryFill: View? = null
    private var batteryRest: View? = null
    private var weatherIcon: TextView? = null
    private var weatherTemp: TextView? = null
    private var weatherSub: TextView? = null
    private var prayerNext: TextView? = null
    private var prayerHijri: TextView? = null
    private var prayerRow: LinearLayout? = null
    private var campaignImg: ImageView? = null
    private var campaignTag: TextView? = null
    private var musicChip: TextView? = null

    private val musicListener: () -> Unit = { runOnUiThread { updateMusicChip() } }

    private var weatherBusy = false
    private var prayerBusy = false

    // gesture state
    private var gDownX = 0f
    private var gDownY = 0f
    private var gEligible = false
    private var gLong = false
    private var lastTapTime = 0L
    private val longRunnable = Runnable {
        gLong = true
        showHomeMenu()
    }

    private val ticker = object : Runnable {
        override fun run() {
            renderBattery()
            renderPrayer()
            maybeAdvanceWallpaper()
            maybeRefreshNet()
            handler.postDelayed(this, 30000)
        }
    }

    private val campaignTicker = object : Runnable {
        override fun run() {
            nextCampaign()
            handler.postDelayed(this, 4500)
        }
    }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshApps()
        }
    }

    // ------------------------------------------------------------ helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h, weight)

    private fun fg(): Int = if (cfg.dark) Color.WHITE else Color.parseColor("#14181F")

    private fun fgSoft(): Int =
        if (cfg.dark) Color.argb(185, 255, 255, 255) else Color.argb(185, 20, 24, 31)

    private fun cardColor(): Int =
        if (cfg.dark) Color.argb(125, 0, 0, 0) else Color.argb(190, 255, 255, 255)

    private fun roundBg(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun cornerFor(size: Int): Float {
        val f = when (cfg.shape) {
            1 -> 0.5f
            2 -> 0.12f
            else -> 0.24f
        }
        return size * f
    }

    private fun iconDp(): Int = when (cfg.iconSize) {
        0 -> 50
        2 -> 64
        else -> 56
    }

    private fun roundIcon(size: Int, d: Drawable): ImageView {
        val iv = ImageView(this)
        iv.setImageDrawable(d)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, cornerFor(view.width))
            }
        }
        iv.clipToOutline = true
        iv.layoutParams = LinearLayout.LayoutParams(size, size)
        return iv
    }

    private fun clipRound(v: View, radiusDp: Int) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(radiusDp).toFloat())
            }
        }
        v.clipToOutline = true
    }

    private fun choose(title: String, items: List<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(items.toTypedArray()) { _, which -> onPick(which) }
            .show()
    }

    private fun prompt(title: String, hint: String, initial: String, onOk: (String) -> Unit) {
        val et = EditText(this)
        et.hint = hint
        et.setText(initial)
        et.setSingleLine(true)
        val wrap = FrameLayout(this)
        wrap.setPadding(dp(20), dp(8), dp(20), 0)
        wrap.addView(et)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(wrap)
            .setPositiveButton("OK") { _, _ -> onOk(et.text.toString()) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)
        homeList = cfg.loadHome()

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        buildUi()
        applyWallpaper(cfg.wallpaper, false)
        MusicPlayer.init(this, cfg.loadSongs())
        MusicPlayer.addListener(musicListener)
        refreshApps()
        applyTheme()

        val f = IntentFilter()
        f.addAction(Intent.ACTION_PACKAGE_ADDED)
        f.addAction(Intent.ACTION_PACKAGE_REMOVED)
        f.addAction(Intent.ACTION_PACKAGE_CHANGED)
        f.addDataScheme("package")
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(packageReceiver, f, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(packageReceiver, f)
        }
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(ticker)
        handler.removeCallbacks(campaignTicker)
        handler.post(ticker)
        handler.postDelayed(campaignTicker, 4500)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
        handler.removeCallbacks(campaignTicker)
        handler.removeCallbacks(longRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        MusicPlayer.removeListener(musicListener)
        try {
            unregisterReceiver(packageReceiver)
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------ UI

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        wallpaperView = ImageView(this)
        wallpaperView.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(wallpaperView, FrameLayout.LayoutParams(-1, -1))

        val shade = View(this)
        shade.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(90, 0, 0, 0), Color.argb(0, 0, 0, 0), Color.argb(120, 0, 0, 0))
        )
        root.addView(shade, FrameLayout.LayoutParams(-1, -1))

        homeLayer = LinearLayout(this)
        homeLayer.orientation = LinearLayout.VERTICAL

        dots = LinearLayout(this)
        dots.orientation = LinearLayout.HORIZONTAL
        dots.gravity = Gravity.CENTER

        pager = ViewPager(this)
        pager.id = View.generateViewId()
        pager.adapter = HomePagerAdapter()
        pager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}
            override fun onPageSelected(position: Int) {
                updateDots(position)
            }

            override fun onPageScrollStateChanged(state: Int) {}
        })
        homeLayer.addView(pager, lp(-1, 0, 1f))
        homeLayer.addView(dots, lp(-1, dp(18)))

        dockRow = LinearLayout(this)
        dockRow.orientation = LinearLayout.HORIZONTAL
        dockRow.gravity = Gravity.CENTER
        dockRow.setPadding(dp(14), dp(12), dp(14), dp(12))
        homeLayer.addView(
            dockRow,
            lp(-2, -2).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(14)
                topMargin = dp(4)
            }
        )
        root.addView(homeLayer, FrameLayout.LayoutParams(-1, -1))

        // ---- drawer
        drawerRoot = FrameLayout(this)
        drawerRoot.visibility = View.GONE

        drawerBg = ImageView(this)
        drawerBg.scaleType = ImageView.ScaleType.CENTER_CROP
        drawerRoot.addView(drawerBg, FrameLayout.LayoutParams(-1, -1))

        drawerShade = View(this)
        drawerRoot.addView(drawerShade, FrameLayout.LayoutParams(-1, -1))

        drawerLayer = LinearLayout(this)
        drawerLayer.orientation = LinearLayout.VERTICAL

        val handleBox = FrameLayout(this)
        val handleBar = View(this)
        handleBar.background = roundBg(Color.argb(150, 160, 160, 160), 3)
        handleBox.addView(
            handleBar,
            FrameLayout.LayoutParams(dp(44), dp(5)).apply { gravity = Gravity.CENTER }
        )
        var hy = 0f
        handleBox.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> hy = e.y
                MotionEvent.ACTION_UP -> if (e.y - hy > dp(30) || abs(e.y - hy) < dp(6)) closeDrawer()
            }
            true
        }
        drawerLayer.addView(handleBox, lp(-1, dp(36)))

        val searchRow = LinearLayout(this)
        searchRow.orientation = LinearLayout.HORIZONTAL
        searchRow.gravity = Gravity.CENTER_VERTICAL

        searchBox = EditText(this)
        searchBox.hint = "Search apps..."
        searchBox.textSize = 16f
        searchBox.setSingleLine(true)
        searchBox.inputType = InputType.TYPE_CLASS_TEXT
        searchBox.setPadding(dp(18), dp(10), dp(18), dp(10))
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterApps(s?.toString() ?: "")
            }
        })
        searchRow.addView(searchBox, lp(0, -2, 1f))

        gear = TextView(this)
        gear.text = "⚙"
        gear.textSize = 24f
        gear.gravity = Gravity.CENTER
        gear.setOnClickListener { showSettings() }
        searchRow.addView(gear, lp(dp(46), dp(46)))

        drawerLayer.addView(
            searchRow,
            lp(-1, -2).apply {
                leftMargin = dp(18)
                rightMargin = dp(10)
                bottomMargin = dp(8)
            }
        )

        grid = GridView(this)
        grid.numColumns = 4
        grid.verticalSpacing = dp(6)
        grid.selector = GradientDrawable().apply { setColor(Color.TRANSPARENT) }
        grid.setPadding(dp(6), dp(6), dp(6), dp(6))
        grid.clipToPadding = false
        adapter = AppAdapter(emptyList())
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> launch(adapter.items[pos]) }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            showAppMenu(adapter.items[pos])
            true
        }
        drawerLayer.addView(grid, lp(-1, 0, 1f))

        drawerRoot.addView(drawerLayer, FrameLayout.LayoutParams(-1, -1))
        root.addView(drawerRoot, FrameLayout.LayoutParams(-1, -1))

        @Suppress("DEPRECATION")
        root.setOnApplyWindowInsetsListener { _, insets ->
            val top = insets.systemWindowInsetTop
            val bottom = insets.systemWindowInsetBottom
            homeLayer.setPadding(0, top, 0, bottom)
            drawerLayer.setPadding(0, top, 0, bottom)
            insets
        }

        setContentView(root)
    }

    private fun applyTheme() {
        drawerShade.setBackgroundColor(
            if (cfg.dark) Color.argb(205, 0, 0, 0) else Color.argb(222, 255, 255, 255)
        )
        searchBox.setTextColor(fg())
        searchBox.setHintTextColor(fgSoft())
        searchBox.background = roundBg(
            if (cfg.dark) Color.argb(70, 255, 255, 255) else Color.argb(50, 0, 0, 0), 22
        )
        gear.setTextColor(fg())
        adapter.notifyDataSetChanged()
        buildDock()
        rebuildHome()
    }

    // ------------------------------------------------------------ pager

    private fun pageCount(): Int {
        val appPages = maxOf(1, (homeList.size + perPage - 1) / perPage)
        return 1 + appPages
    }

    private inner class HomePagerAdapter : PagerAdapter() {
        override fun getCount(): Int = pageCount()

        override fun isViewFromObject(view: View, obj: Any): Boolean = view === obj

        override fun instantiateItem(container: ViewGroup, position: Int): Any {
            val v = if (position == 0) buildWidgetPage() else buildAppsPage(position - 1)
            container.addView(v)
            return v
        }

        override fun destroyItem(container: ViewGroup, position: Int, obj: Any) {
            container.removeView(obj as View)
        }

        override fun getItemPosition(obj: Any): Int = POSITION_NONE
    }

    private fun rebuildHome() {
        pager.adapter?.notifyDataSetChanged()
        updateDots(pager.currentItem)
    }

    private fun updateDots(sel: Int) {
        dots.removeAllViews()
        val n = pageCount()
        if (n <= 1) return
        for (i in 0 until n) {
            val d = View(this)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(if (i == sel) Color.WHITE else Color.argb(110, 255, 255, 255))
            d.background = g
            val s = if (i == sel) 8 else 6
            dots.addView(d, lp(dp(s), dp(s)).apply {
                leftMargin = dp(3)
                rightMargin = dp(3)
            })
        }
    }

    // ------------------------------------------------------------ widget page

    private fun buildWidgetPage(): View {
        batteryPct = null
        batteryFill = null
        batteryRest = null
        weatherIcon = null
        weatherTemp = null
        weatherSub = null
        prayerNext = null
        prayerHijri = null
        prayerRow = null
        campaignImg = null
        campaignTag = null
        musicChip = null

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.gravity = Gravity.CENTER_HORIZONTAL
        page.setPadding(dp(16), dp(10), dp(16), dp(6))

        val clock = TextClock(this)
        clock.format12Hour = "h:mm"
        clock.format24Hour = "HH:mm"
        clock.textSize = 56f
        clock.setTextColor(Color.WHITE)
        clock.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        clock.setShadowLayer(10f, 0f, 2f, Color.argb(160, 0, 0, 0))
        page.addView(clock, lp(-2, -2))

        val date = TextClock(this)
        date.format12Hour = "EEEE, d MMMM"
        date.format24Hour = "EEEE, d MMMM"
        date.textSize = 15f
        date.setTextColor(Color.WHITE)
        date.setShadowLayer(8f, 0f, 2f, Color.argb(160, 0, 0, 0))
        page.addView(date, lp(-2, -2))

        val search = TextView(this)
        search.text = "🔍  Search apps..."
        search.textSize = 15f
        search.setTextColor(fgSoft())
        search.setPadding(dp(18), dp(12), dp(18), dp(12))
        search.background = roundBg(cardColor(), 24)
        search.setOnClickListener { openDrawer(true) }
        page.addView(search, lp(-1, -2).apply {
            topMargin = dp(12)
            bottomMargin = dp(8)
        })
        page.addView(buildChipsRow(), lp(-1, -2).apply { bottomMargin = dp(10) })

        if (cfg.showWeather || cfg.showBattery) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            if (cfg.showWeather) {
                row.addView(buildWeatherCard(), lp(0, -1, 1f).apply {
                    rightMargin = if (cfg.showBattery) dp(5) else 0
                })
            }
            if (cfg.showBattery) {
                row.addView(buildBatteryCard(), lp(0, -1, 1f).apply {
                    leftMargin = if (cfg.showWeather) dp(5) else 0
                })
            }
            page.addView(row, lp(-1, -2).apply { bottomMargin = dp(10) })
        }

        if (cfg.showPrayer) {
            page.addView(buildPrayerCard(), lp(-1, -2).apply { bottomMargin = dp(10) })
        }

        if (cfg.showCampaign) {
            val c = buildCampaignCard()
            c.minimumHeight = dp(110)
            page.addView(c, lp(-1, 0, 1f))
        } else {
            page.addView(View(this), lp(-1, 0, 1f))
        }

        renderBattery()
        renderWeather()
        renderPrayer()
        return page
    }

    private fun buildWeatherCard(): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(dp(12), dp(10), dp(12), dp(10))
        card.background = roundBg(cardColor(), 18)

        val ic = TextView(this)
        ic.textSize = 30f
        weatherIcon = ic
        card.addView(ic, lp(-2, -2).apply { rightMargin = dp(10) })

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val t = TextView(this)
        t.textSize = 22f
        t.setTextColor(fg())
        t.typeface = Typeface.DEFAULT_BOLD
        weatherTemp = t
        val c = TextView(this)
        c.textSize = 11f
        c.setTextColor(fgSoft())
        c.maxLines = 1
        c.ellipsize = TextUtils.TruncateAt.END
        weatherSub = c
        col.addView(t)
        col.addView(c)
        card.addView(col, lp(0, -2, 1f))

        card.setOnClickListener { showLocationDialog() }
        return card
    }

    private fun buildBatteryCard(): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(dp(12), dp(10), dp(12), dp(10))
        card.background = roundBg(cardColor(), 18)

        val pct = TextView(this)
        pct.textSize = 22f
        pct.setTextColor(fg())
        pct.typeface = Typeface.DEFAULT_BOLD
        batteryPct = pct
        card.addView(pct)

        val sub = TextView(this)
        sub.text = "Battery"
        sub.textSize = 11f
        sub.setTextColor(fgSoft())
        card.addView(sub)

        val track = LinearLayout(this)
        track.orientation = LinearLayout.HORIZONTAL
        track.background = roundBg(Color.argb(70, 128, 128, 128), 4)
        val fill = View(this)
        fill.background = roundBg(cfg.accent, 4)
        val rest = View(this)
        track.addView(fill, lp(0, dp(8), 50f))
        track.addView(rest, lp(0, dp(8), 50f))
        batteryFill = fill
        batteryRest = rest
        card.addView(track, lp(-1, dp(8)).apply { topMargin = dp(8) })
        return card
    }

    private fun buildPrayerCard(): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(12), dp(10), dp(12), dp(10))
        card.background = roundBg(cardColor(), 18)

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "🕌  Prayer Times"
        title.textSize = 13f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(fg())
        head.addView(title, lp(0, -2, 1f))
        val hj = TextView(this)
        hj.textSize = 11f
        hj.setTextColor(fgSoft())
        prayerHijri = hj
        head.addView(hj)
        card.addView(head)

        val nx = TextView(this)
        nx.textSize = 12f
        nx.setTextColor(fgSoft())
        prayerNext = nx
        card.addView(nx, lp(-1, -2).apply {
            topMargin = dp(2)
            bottomMargin = dp(6)
        })

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        prayerRow = row
        card.addView(row, lp(-1, -2))

        card.setOnClickListener {
            if (cfg.city.isEmpty()) showLocationDialog()
        }
        return card
    }

    private fun buildCampaignCard(): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = roundBg(cardColor(), 18)
        clipRound(card, 18)

        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.gravity = Gravity.CENTER_VERTICAL
        left.setPadding(dp(16), dp(10), dp(8), dp(10))

        val tag = TextView(this)
        tag.textSize = 11f
        tag.typeface = Typeface.DEFAULT_BOLD
        tag.setTextColor(cfg.accent)
        tag.text = campaignTags[campaignIdx].uppercase()
        campaignTag = tag
        left.addView(tag)

        val hon = TextView(this)
        hon.text = "Hon."
        hon.textSize = 13f
        hon.setTextColor(fgSoft())
        left.addView(hon, lp(-2, -2).apply { topMargin = dp(4) })

        val n1 = TextView(this)
        n1.text = "Musa Yusuf"
        n1.textSize = 21f
        n1.typeface = Typeface.DEFAULT_BOLD
        n1.setTextColor(fg())
        left.addView(n1)

        val n2 = TextView(this)
        n2.text = "Drogba"
        n2.textSize = 21f
        n2.typeface = Typeface.DEFAULT_BOLD
        n2.setTextColor(cfg.accent)
        left.addView(n2)

        val sub = TextView(this)
        sub.text = "House of Assembly • Fika East"
        sub.textSize = 10.5f
        sub.setTextColor(fgSoft())
        sub.maxLines = 2
        left.addView(sub, lp(-2, -2).apply { topMargin = dp(4) })

        card.addView(left, lp(0, -1, 1f))

        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.setImageBitmap(campaignBmp(campaignIdx))
        campaignImg = img
        card.addView(img, lp(dp(130), -1))

        card.setOnClickListener { nextCampaign() }
        return card
    }

    private fun campaignBmp(i: Int): Bitmap? {
        val idx = if (i in campaignRes.indices) i else 0
        if (campaignBmps[idx] == null) {
            campaignBmps[idx] = decodeRes(campaignRes[idx], dp(160), dp(160))
        }
        return campaignBmps[idx]
    }

    private fun nextCampaign() {
        val img = campaignImg ?: return
        campaignIdx = (campaignIdx + 1) % campaignRes.size
        val bmp = campaignBmp(campaignIdx)
        img.animate().alpha(0f).setDuration(250).withEndAction {
            img.setImageBitmap(bmp)
            campaignTag?.text = campaignTags[campaignIdx].uppercase()
            img.animate().alpha(1f).setDuration(300).start()
        }.start()
    }

    // ------------------------------------------------------------ widget rendering

    private fun renderBattery() {
        val pctView = batteryPct ?: return
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING ||
            st == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        pctView.text = (if (charging) "⚡ " else "") + pct + "%"
        val f = batteryFill
        val r = batteryRest
        if (f != null && r != null) {
            (f.layoutParams as LinearLayout.LayoutParams).weight = pct.toFloat()
            (r.layoutParams as LinearLayout.LayoutParams).weight = (100 - pct).toFloat()
            f.requestLayout()
            r.requestLayout()
        }
    }

    private fun weatherIconFor(code: Int): String = when (code) {
        0 -> "☀️"
        1, 2 -> "🌤️"
        3 -> "☁️"
        45, 48 -> "🌫️"
        in 51..67 -> "🌧️"
        in 80..82 -> "🌧️"
        in 95..99 -> "⛈️"
        else -> "🌡️"
    }

    private fun weatherDescFor(code: Int): String = when (code) {
        0 -> "Clear sky"
        1, 2 -> "Partly cloudy"
        3 -> "Cloudy"
        45, 48 -> "Foggy"
        in 51..57 -> "Drizzle"
        in 61..67 -> "Rain"
        in 80..82 -> "Rain"
        in 95..99 -> "Thunderstorm"
        else -> ""
    }

    private fun renderWeather() {
        val ic = weatherIcon ?: return
        val t = weatherTemp ?: return
        val s = weatherSub ?: return
        if (cfg.city.isEmpty()) {
            ic.text = "🌤️"
            t.text = "--°"
            s.text = "Tap to set city"
            return
        }
        val parts = cfg.weatherCache.split("|")
        if (parts.size < 2) {
            ic.text = "🌤️"
            t.text = "--°"
            s.text = cfg.city
            return
        }
        val code = parts[1].toIntOrNull() ?: -1
        ic.text = weatherIconFor(code)
        t.text = parts[0] + "°C"
        val d = weatherDescFor(code)
        s.text = if (d.isEmpty()) cfg.city else cfg.city + " • " + d
    }

    private fun toMin(hhmm: String): Int {
        return try {
            val p = hhmm.trim().take(5).split(":")
            p[0].toInt() * 60 + p[1].toInt()
        } catch (e: Exception) {
            -1
        }
    }

    private fun renderPrayer() {
        val nx = prayerNext ?: return
        val row = prayerRow ?: return
        val hj = prayerHijri
        row.removeAllViews()
        if (cfg.city.isEmpty()) {
            nx.text = "Tap to set your city"
            hj?.text = ""
            return
        }
        val parts = cfg.prayerCache.split("|")
        if (parts.size < 6) {
            nx.text = "Loading..."
            hj?.text = ""
            return
        }
        hj?.text = parts[5]
        val names = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
        val cal = Calendar.getInstance()
        val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        var next = -1
        for (i in 0 until 5) {
            val m = toMin(parts[i])
            if (m > nowMin) {
                next = i
                break
            }
        }
        if (next >= 0) {
            val diff = toMin(parts[next]) - nowMin
            val h = diff / 60
            val m = diff % 60
            val left = if (h > 0) h.toString() + "s " + m + "m" else m.toString() + "m"
            nx.text = "Next: " + names[next] + " • " + parts[next].trim().take(5) + " (in " + left + ")"
        } else {
            nx.text = "Next: Fajr tomorrow • " + parts[0].trim().take(5)
        }
        val hi = if (next >= 0) next else 0
        for (i in 0 until 5) {
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            val n = TextView(this)
            n.text = names[i]
            n.textSize = 10f
            n.setTextColor(fgSoft())
            n.gravity = Gravity.CENTER
            val tm = TextView(this)
            tm.text = parts[i].trim().take(5)
            tm.textSize = 13f
            tm.typeface = Typeface.DEFAULT_BOLD
            tm.setTextColor(if (i == hi) cfg.accent else fg())
            tm.gravity = Gravity.CENTER
            cell.addView(n)
            cell.addView(tm)
            row.addView(cell, lp(0, -2, 1f))
        }
    }

    // ------------------------------------------------------------ network (weather, prayer)

    private fun todayStr(): String = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date())

    private fun maybeRefreshNet() {
        if (cfg.lat.isEmpty() || cfg.lon.isEmpty()) return
        if (System.currentTimeMillis() - cfg.weatherTime > 30 * 60 * 1000L) fetchWeather()
        if (cfg.prayerDate != todayStr()) fetchPrayer()
    }

    private fun parseWeather(s: String?): String? {
        if (s == null) return null
        return try {
            val cur = JSONObject(s).getJSONObject("current")
            Math.round(cur.getDouble("temperature_2m")).toString() + "|" + cur.getInt("weather_code")
        } catch (e: Exception) {
            null
        }
    }

    private fun fetchWeather() {
        if (weatherBusy) return
        weatherBusy = true
        val lat = cfg.lat
        val lon = cfg.lon
        Thread {
            val s = Net.get(
                "https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon +
                    "&current=temperature_2m,weather_code&timezone=auto"
            )
            val ok = parseWeather(s)
            runOnUiThread {
                weatherBusy = false
                if (ok != null) {
                    cfg.weatherCache = ok
                    cfg.weatherTime = System.currentTimeMillis()
                    renderWeather()
                }
            }
        }.start()
    }

    private fun parsePrayer(s: String?): String? {
        if (s == null) return null
        return try {
            val data = JSONObject(s).getJSONObject("data")
            val t = data.getJSONObject("timings")
            val h = data.getJSONObject("date").getJSONObject("hijri")
            val hijri = h.getString("day") + " " + h.getJSONObject("month").getString("en") + " " + h.getString("year")
            listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
                .joinToString("|") { k -> t.getString(k).trim().take(5) } + "|" + hijri
        } catch (e: Exception) {
            null
        }
    }

    private fun fetchPrayer() {
        if (prayerBusy) return
        prayerBusy = true
        val lat = cfg.lat
        val lon = cfg.lon
        val date = todayStr()
        Thread {
            val s = Net.get(
                "https://api.aladhan.com/v1/timings/" + date + "?latitude=" + lat +
                    "&longitude=" + lon + "&method=3"
            )
            val ok = parsePrayer(s)
            runOnUiThread {
                prayerBusy = false
                if (ok != null) {
                    cfg.prayerCache = ok
                    cfg.prayerDate = date
                    renderPrayer()
                }
            }
        }.start()
    }

    private fun parseGeo(s: String?): String? {
        if (s == null) return null
        return try {
            val arr = JSONObject(s).optJSONArray("results") ?: return null
            val o = arr.getJSONObject(0)
            o.getString("name") + "|" + o.getDouble("latitude") + "|" + o.getDouble("longitude")
        } catch (e: Exception) {
            null
        }
    }

    private fun showLocationDialog() {
        prompt("Your city", "e.g. Potiskum", cfg.city) { name ->
            val n = name.trim()
            if (n.isEmpty()) return@prompt
            toast("Searching...")
            Thread {
                val s = Net.get(
                    "https://geocoding-api.open-meteo.com/v1/search?name=" + Uri.encode(n) +
                        "&count=1&language=en&format=json"
                )
                val r = parseGeo(s)
                runOnUiThread {
                    if (r == null) {
                        toast("City not found. Check your internet connection or the spelling.")
                    } else {
                        val p = r.split("|")
                        cfg.city = p[0]
                        cfg.lat = p[1]
                        cfg.lon = p[2]
                        cfg.weatherTime = 0L
                        cfg.weatherCache = ""
                        cfg.prayerDate = ""
                        cfg.prayerCache = ""
                        renderWeather()
                        renderPrayer()
                        maybeRefreshNet()
                        toast("City set: " + p[0])
                    }
                }
            }.start()
        }
    }

    // ------------------------------------------------------------ wallpapers

    private fun sampleFor(w: Int, h: Int, reqW: Int, reqH: Int): Int {
        var sample = 1
        while (w / (sample * 2) >= reqW && h / (sample * 2) >= reqH) sample *= 2
        return sample
    }

    private fun decodeRes(resId: Int, reqW: Int, reqH: Int): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeResource(resources, resId, o)
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sampleFor(o.outWidth, o.outHeight, reqW, reqH)
        o2.inPreferredConfig = Bitmap.Config.RGB_565
        return BitmapFactory.decodeResource(resources, resId, o2)
    }

    private fun decodeFile(path: String, reqW: Int, reqH: Int): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(path, o)
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sampleFor(o.outWidth, o.outHeight, reqW, reqH)
        o2.inPreferredConfig = Bitmap.Config.RGB_565
        return BitmapFactory.decodeFile(path, o2)
    }

    private fun wallpapers(): List<Wp> {
        val l = mutableListOf<Wp>()
        for (r in builtinWp) l.add(Wp(r, null))
        for (f in cfg.customWps) {
            if (File(filesDir, f).exists()) l.add(Wp(0, f))
        }
        return l
    }

    private fun decodeWp(w: Wp, rw: Int, rh: Int): Bitmap? {
        val f = w.file
        return if (f != null) decodeFile(File(filesDir, f).absolutePath, rw, rh) else decodeRes(w.res, rw, rh)
    }

    private fun applyWallpaper(index: Int, animate: Boolean) {
        val list = wallpapers()
        val i = if (index in list.indices) index else 0
        cfg.wallpaper = i
        val dm = resources.displayMetrics
        val bmp = decodeWp(list[i], dm.widthPixels, dm.heightPixels)
        if (!animate) {
            wallpaperView.setImageBitmap(bmp)
            return
        }
        wallpaperView.animate().alpha(0f).setDuration(300).withEndAction {
            wallpaperView.setImageBitmap(bmp)
            wallpaperView.animate().alpha(1f).setDuration(400).start()
        }.start()
    }

    private fun maybeAdvanceWallpaper() {
        if (cfg.slideshow == 0) return
        val interval = if (cfg.slideshow == 1) 3600000L else 86400000L
        val now = System.currentTimeMillis()
        if (now - cfg.lastSlide < interval) return
        cfg.lastSlide = now
        applyWallpaper(cfg.wallpaper + 1, true)
    }

    private fun showWallpaperPicker() {
        val list = wallpapers()
        val holder = arrayOfNulls<AlertDialog>(1)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(12), dp(12), dp(12), dp(12))
        for (i in list.indices) {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(decodeWp(list[i], dp(110), dp(190)))
            clipRound(iv, 14)
            iv.setOnClickListener {
                applyWallpaper(i, true)
                holder[0]?.dismiss()
            }
            if (list[i].file != null) {
                iv.setOnLongClickListener {
                    holder[0]?.dismiss()
                    confirmDeleteWallpaper(list[i])
                    true
                }
            }
            row.addView(iv, lp(dp(110), dp(190)).apply { rightMargin = dp(10) })
        }
        val plus = TextView(this)
        plus.text = "＋\nPhoto from\nyour phone"
        plus.textSize = 13f
        plus.gravity = Gravity.CENTER
        plus.setTextColor(Color.WHITE)
        plus.background = roundBg(Color.argb(90, 128, 128, 128), 14)
        plus.setOnClickListener {
            holder[0]?.dismiss()
            pickCustomWallpaper()
        }
        row.addView(plus, lp(dp(110), dp(190)))

        val scroll = HorizontalScrollView(this)
        scroll.addView(row)
        val d = AlertDialog.Builder(this)
            .setTitle("Choose wallpaper")
            .setView(scroll)
            .setNegativeButton("Close", null)
            .create()
        holder[0] = d
        d.show()
    }

    private fun confirmDeleteWallpaper(w: Wp) {
        val f = w.file ?: return
        AlertDialog.Builder(this)
            .setTitle("Delete this photo?")
            .setPositiveButton("Delete") { _, _ ->
                File(filesDir, f).delete()
                val l = cfg.customWps
                l.remove(f)
                cfg.customWps = l
                applyWallpaper(0, true)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun pickCustomWallpaper() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        try {
            startActivityForResult(i, REQ_PICK)
        } catch (e: Exception) {
            toast("Can't open the gallery")
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && data != null) {
            if (requestCode == REQ_PICK) {
                val uri = data.data
                if (uri != null) importWallpaper(uri)
            } else if (requestCode == REQ_SONGS) {
                importSongs(data)
            }
        }
    }

    private fun importWallpaper(uri: Uri) {
        Thread {
            try {
                val dm = resources.displayMetrics
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                contentResolver.openInputStream(uri)?.use { s -> BitmapFactory.decodeStream(s, null, o) }
                o.inSampleSize = sampleFor(o.outWidth, o.outHeight, dm.widthPixels, dm.heightPixels)
                o.inJustDecodeBounds = false
                val bmp = contentResolver.openInputStream(uri)?.use { s -> BitmapFactory.decodeStream(s, null, o) }
                if (bmp != null) {
                    val name = "wpc_" + System.currentTimeMillis() + ".jpg"
                    FileOutputStream(File(filesDir, name)).use { out ->
                        bmp.compress(Bitmap.CompressFormat.JPEG, 88, out)
                    }
                    val l = cfg.customWps
                    l.add(name)
                    cfg.customWps = l
                    runOnUiThread {
                        applyWallpaper(wallpapers().size - 1, true)
                        toast("Wallpaper added")
                    }
                } else {
                    runOnUiThread { toast("Couldn't load the photo") }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Couldn't load the photo") }
            }
        }.start()
    }

    // ------------------------------------------------------------ apps

    private fun appByPkg(pkg: String): AppItem? = allApps.firstOrNull { a -> a.pkg == pkg }

    private fun saveHome() {
        cfg.saveHome(homeList)
    }

    private fun refreshApps() {
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allApps = pm.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                AppItem(
                    it.loadLabel(pm).toString(),
                    it.activityInfo.packageName,
                    it.activityInfo.name,
                    it.loadIcon(pm)
                )
            }
            .sortedBy { it.label.lowercase() }
        val hidden = cfg.hidden
        visibleApps = allApps.filter { a -> !hidden.contains(a.pkg) }

        if (allApps.isNotEmpty()) {
            var changed = false
            val iter = homeList.iterator()
            while (iter.hasNext()) {
                val e = iter.next()
                val before = e.pkgs.size
                e.pkgs.removeAll { p -> allApps.none { a -> a.pkg == p } }
                if (e.pkgs.size != before) changed = true
                if (e.pkgs.isEmpty()) {
                    iter.remove()
                    changed = true
                }
            }
            if (changed) saveHome()
        }

        filterApps(searchBox.text.toString())
        buildDock()
        rebuildHome()
    }

    private fun filterApps(q: String) {
        val t = q.trim()
        adapter.items = if (t.isEmpty()) visibleApps else visibleApps.filter { a -> a.label.contains(t, ignoreCase = true) }
        adapter.notifyDataSetChanged()
    }

    private fun launch(a: AppItem) {
        if (cfg.locked.contains(a.pkg)) {
            askPin("PIN for " + a.label) { launchNow(a) }
            return
        }
        launchNow(a)
    }

    private fun launchNow(a: AppItem) {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(a.pkg, a.activity)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast("Can't open this app")
        }
        if (drawerOpen) closeDrawer()
    }

    private inner class AppAdapter(var items: List<AppItem>) : BaseAdapter() {
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val item = items[position]
            val cell = LinearLayout(this@MainActivity)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(dp(2), dp(8), dp(2), dp(8))
            cell.addView(roundIcon(dp(iconDp()), item.icon))
            if (cfg.labels) {
                val tv = TextView(this@MainActivity)
                tv.text = item.label
                tv.setTextColor(fg())
                tv.textSize = 11.5f
                tv.maxLines = 1
                tv.gravity = Gravity.CENTER
                tv.ellipsize = TextUtils.TruncateAt.END
                cell.addView(tv, lp(-1, -2).apply { topMargin = dp(5) })
            }
            return cell
        }
    }

    // long-press menu in the drawer
    private fun showAppMenu(a: AppItem) {
        val isLocked = cfg.locked.contains(a.pkg)
        val opts = listOf(
            "Add to home screen",
            "Add to dock",
            "Hide app",
            if (isLocked) "Remove lock (PIN)" else "Lock with PIN",
            "App info",
            "Uninstall"
        )
        choose(a.label, opts) { which ->
            when (which) {
                0 -> addToHome(a)
                1 -> pinToDock(a)
                2 -> ensurePin { hideApp(a) }
                3 -> if (isLocked) {
                    askPin("Remove lock") { unlockApp(a) }
                } else {
                    ensurePin { lockApp(a) }
                }
                4 -> {
                    val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg))
                    try {
                        startActivity(i)
                    } catch (e: Exception) {
                    }
                }
                5 -> {
                    val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg))
                    try {
                        startActivity(i)
                    } catch (e: Exception) {
                        toast("Can't uninstall this app")
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ home screen apps and folders

    private fun makeCell(icon: View, label: String): LinearLayout {
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.VERTICAL
        cell.gravity = Gravity.CENTER_HORIZONTAL
        cell.setPadding(dp(2), dp(8), dp(2), dp(8))
        cell.addView(icon)
        if (cfg.labels) {
            val tv = TextView(this)
            tv.text = label
            tv.setTextColor(Color.WHITE)
            tv.textSize = 11.5f
            tv.maxLines = 1
            tv.gravity = Gravity.CENTER
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.setShadowLayer(4f, 0f, 1f, Color.BLACK)
            cell.addView(tv, lp(-1, -2).apply { topMargin = dp(5) })
        }
        return cell
    }

    private fun folderIcon(e: HomeEntry, size: Int): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.setColor(Color.argb(120, 255, 255, 255))
        g.cornerRadius = cornerFor(size)
        box.background = g
        val mini = size * 38 / 100
        val apps = e.pkgs.mapNotNull { p -> appByPkg(p) }.take(4)
        for (r in 0..1) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (c in 0..1) {
                val a = apps.getOrNull(r * 2 + c)
                val v: View = if (a != null) {
                    val iv = ImageView(this)
                    iv.setImageDrawable(a.icon)
                    iv.scaleType = ImageView.ScaleType.FIT_CENTER
                    iv
                } else {
                    View(this)
                }
                row.addView(v, lp(mini, mini).apply {
                    leftMargin = dp(1)
                    rightMargin = dp(1)
                    topMargin = dp(1)
                    bottomMargin = dp(1)
                })
            }
            box.addView(row)
        }
        box.layoutParams = LinearLayout.LayoutParams(size, size)
        return box
    }

    private fun entryCell(e: HomeEntry): View? {
        val size = dp(iconDp())
        val folderName = e.folder
        if (folderName != null) {
            val cell = makeCell(folderIcon(e, size), folderName)
            cell.setOnClickListener { openFolder(e) }
            cell.setOnLongClickListener {
                folderMenu(e)
                true
            }
            return cell
        }
        val app = appByPkg(e.pkgs.firstOrNull() ?: "") ?: return null
        val cell = makeCell(roundIcon(size, app.icon), app.label)
        cell.setOnClickListener { launch(app) }
        cell.setOnLongClickListener {
            homeAppMenu(e, app)
            true
        }
        return cell
    }

    private fun buildAppsPage(pageIdx: Int): View {
        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setPadding(dp(8), dp(28), dp(8), dp(8))
        val entries = homeList.drop(pageIdx * perPage).take(perPage)
        if (entries.isEmpty() && pageIdx == 0) {
            val hint = TextView(this)
            hint.text = "Nothing here yet.\n\nSwipe up to open the app list, press and hold an app, then choose \"Add to home screen\"."
            hint.setTextColor(Color.WHITE)
            hint.textSize = 14f
            hint.gravity = Gravity.CENTER
            hint.setShadowLayer(6f, 0f, 1f, Color.BLACK)
            hint.setPadding(dp(24), dp(80), dp(24), 0)
            page.addView(hint, lp(-1, -2))
            return page
        }
        var row: LinearLayout? = null
        var inRow = 0
        for (e in entries) {
            val cell = entryCell(e) ?: continue
            if (row == null || inRow == cols) {
                row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                page.addView(row, lp(-1, -2))
                inRow = 0
            }
            row.addView(cell, lp(0, -2, 1f))
            inRow++
        }
        if (row != null) {
            while (inRow < cols) {
                row.addView(View(this), lp(0, 1, 1f))
                inRow++
            }
        }
        return page
    }

    private fun addToHome(a: AppItem) {
        val exists = homeList.any { e -> e.pkgs.contains(a.pkg) }
        if (exists) {
            toast("Already on the home screen")
            return
        }
        homeList.add(HomeEntry(null, mutableListOf(a.pkg)))
        saveHome()
        rebuildHome()
        toast("Added " + a.label + " to the home screen")
    }

    private fun homeAppMenu(e: HomeEntry, app: AppItem) {
        choose(app.label, listOf("Remove from home screen", "Add to folder")) { which ->
            when (which) {
                0 -> {
                    homeList.remove(e)
                    saveHome()
                    rebuildHome()
                }
                1 -> addToFolderFlow(e)
            }
        }
    }

    private fun addToFolderFlow(e: HomeEntry) {
        val folders = homeList.filter { f -> f.folder != null }
        val names = mutableListOf("＋ New folder")
        for (f in folders) names.add(f.folder ?: "Folder")
        choose("Add to folder", names) { which ->
            if (which == 0) {
                prompt("Folder name", "e.g. Social", "") { name ->
                    val n = if (name.isBlank()) "Folder" else name.trim()
                    val idx = homeList.indexOf(e)
                    if (idx >= 0) {
                        homeList[idx] = HomeEntry(n, mutableListOf(e.pkgs[0]))
                        saveHome()
                        rebuildHome()
                    }
                }
            } else {
                val f = folders[which - 1]
                val p = e.pkgs[0]
                if (!f.pkgs.contains(p)) f.pkgs.add(p)
                homeList.remove(e)
                saveHome()
                rebuildHome()
            }
        }
    }

    private fun folderMenu(f: HomeEntry) {
        choose(f.folder ?: "Folder", listOf("Open", "Rename", "Dissolve folder", "Delete folder")) { which ->
            when (which) {
                0 -> openFolder(f)
                1 -> prompt("New name", "Folder name", f.folder ?: "") { name ->
                    if (name.isNotBlank()) {
                        f.folder = name.trim()
                        saveHome()
                        rebuildHome()
                    }
                }
                2 -> {
                    val idx = homeList.indexOf(f)
                    if (idx >= 0) {
                        homeList.removeAt(idx)
                        homeList.addAll(idx, f.pkgs.map { p -> HomeEntry(null, mutableListOf(p)) })
                        saveHome()
                        rebuildHome()
                    }
                }
                3 -> {
                    homeList.remove(f)
                    saveHome()
                    rebuildHome()
                }
            }
        }
    }

    private fun openFolder(f: HomeEntry) {
        val apps = f.pkgs.mapNotNull { p -> appByPkg(p) }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(8), dp(8), dp(8), dp(8))
        val d = AlertDialog.Builder(this)
            .setTitle(f.folder ?: "Folder")
            .setView(box)
            .setNegativeButton("Close", null)
            .create()
        var row: LinearLayout? = null
        var inRow = 0
        for (a in apps) {
            val cell = makeCell(roundIcon(dp(iconDp()), a.icon), a.label)
            cell.setOnClickListener {
                d.dismiss()
                launch(a)
            }
            cell.setOnLongClickListener {
                f.pkgs.remove(a.pkg)
                if (f.pkgs.isEmpty()) homeList.remove(f)
                saveHome()
                rebuildHome()
                d.dismiss()
                toast("Removed " + a.label + " from folder")
                true
            }
            if (row == null || inRow == cols) {
                row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                box.addView(row, lp(-1, -2))
                inRow = 0
            }
            row.addView(cell, lp(0, -2, 1f))
            inRow++
        }
        if (row != null) {
            while (inRow < cols) {
                row.addView(View(this), lp(0, 1, 1f))
                inRow++
            }
        }
        d.show()
    }

    // ------------------------------------------------------------ dock

    private fun defaultDock(): List<AppItem> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("http://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val result = mutableListOf<AppItem>()
        for (intent in intents) {
            val ri = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY) ?: continue
            val pkg = ri.activityInfo.packageName
            val app = visibleApps.firstOrNull { a -> a.pkg == pkg } ?: continue
            if (result.none { r -> r.pkg == app.pkg }) result.add(app)
        }
        return result
    }

    private fun dockApps(): List<AppItem> {
        val saved = cfg.dock
        val list = saved.mapNotNull { pkg -> visibleApps.firstOrNull { a -> a.pkg == pkg } }
        if (list.isNotEmpty()) return list
        return defaultDock()
    }

    private fun buildDock() {
        dockRow.background = roundBg(
            if (cfg.dark) Color.argb(85, 255, 255, 255) else Color.argb(150, 255, 255, 255), 30
        )
        dockRow.removeAllViews()
        for (a in dockApps()) {
            val size = dp(iconDp() + 2)
            val iv = roundIcon(size, a.icon)
            iv.setOnClickListener { launch(a) }
            iv.setOnLongClickListener {
                unpinFromDock(a)
                true
            }
            val l = LinearLayout.LayoutParams(size, size)
            l.leftMargin = dp(8)
            l.rightMargin = dp(8)
            dockRow.addView(iv, l)
        }
    }

    private fun pinToDock(a: AppItem) {
        val cur = dockApps().map { x -> x.pkg }.toMutableList()
        if (cur.contains(a.pkg)) {
            toast("Already in the dock")
            return
        }
        cur.add(a.pkg)
        while (cur.size > 4) cur.removeAt(0)
        cfg.dock = cur
        buildDock()
        toast("Added " + a.label + " to the dock")
    }

    private fun unpinFromDock(a: AppItem) {
        val cur = dockApps().map { x -> x.pkg }.toMutableList()
        cur.remove(a.pkg)
        cfg.dock = cur
        buildDock()
    }

    // ------------------------------------------------------------ PIN, hidden and locked apps

    private fun askPin(title: String, onOk: () -> Unit) {
        val et = EditText(this)
        et.hint = "PIN"
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        val wrap = FrameLayout(this)
        wrap.setPadding(dp(20), dp(8), dp(20), 0)
        wrap.addView(et)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(wrap)
            .setPositiveButton("OK") { _, _ ->
                if (cfg.checkPin(et.text.toString())) onOk() else toast("Wrong PIN")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun setupPin(onDone: () -> Unit) {
        val a = EditText(this)
        a.hint = "New PIN (4+ digits)"
        a.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        val b = EditText(this)
        b.hint = "Repeat PIN"
        b.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.setPadding(dp(20), dp(8), dp(20), 0)
        wrap.addView(a)
        wrap.addView(b)
        AlertDialog.Builder(this)
            .setTitle("Set PIN")
            .setView(wrap)
            .setPositiveButton("OK") { _, _ ->
                val p1 = a.text.toString()
                val p2 = b.text.toString()
                if (p1.length < 4) {
                    toast("PIN is too short (minimum 4 digits)")
                } else if (p1 != p2) {
                    toast("The PINs don't match")
                } else {
                    cfg.setPin(p1)
                    toast("PIN set")
                    onDone()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun ensurePin(then: () -> Unit) {
        if (cfg.hasPin()) then() else setupPin(then)
    }

    private fun hideApp(a: AppItem) {
        val h = cfg.hidden
        if (!h.contains(a.pkg)) h.add(a.pkg)
        cfg.hidden = h
        val d = cfg.dock
        d.remove(a.pkg)
        cfg.dock = d
        for (e in homeList) e.pkgs.remove(a.pkg)
        homeList.removeAll { e -> e.pkgs.isEmpty() }
        saveHome()
        refreshApps()
        toast("Hidden: " + a.label + ". Find it in Settings > Hidden apps")
    }

    private fun lockApp(a: AppItem) {
        val l = cfg.locked
        if (!l.contains(a.pkg)) l.add(a.pkg)
        cfg.locked = l
        toast(a.label + " now requires a PIN in this launcher")
    }

    private fun unlockApp(a: AppItem) {
        val l = cfg.locked
        l.remove(a.pkg)
        cfg.locked = l
        toast("Lock removed")
    }

    private fun showHiddenApps() {
        val hidden = cfg.hidden
        val list = allApps.filter { a -> hidden.contains(a.pkg) }
        if (list.isEmpty()) {
            toast("No hidden apps")
            return
        }
        choose("Hidden apps", list.map { a -> a.label }) { idx ->
            val a = list[idx]
            choose(a.label, listOf("Open", "Unhide")) { which ->
                when (which) {
                    0 -> launchNow(a)
                    1 -> {
                        val h = cfg.hidden
                        h.remove(a.pkg)
                        cfg.hidden = h
                        refreshApps()
                        toast("Restored " + a.label)
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ menus and settings

    private fun showHomeMenu() {
        choose("Musa Launcher", listOf("Change wallpaper", "Widgets", "Launcher settings")) { which ->
            when (which) {
                0 -> showWallpaperPicker()
                1 -> showWidgetToggles()
                2 -> showSettings()
            }
        }
    }

    private fun showWidgetToggles() {
        val names = arrayOf("Weather", "Prayer times", "Battery", "Campaign card")
        val checked = booleanArrayOf(cfg.showWeather, cfg.showPrayer, cfg.showBattery, cfg.showCampaign)
        AlertDialog.Builder(this)
            .setTitle("Widgets")
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("OK") { _, _ ->
                cfg.showWeather = checked[0]
                cfg.showPrayer = checked[1]
                cfg.showBattery = checked[2]
                cfg.showCampaign = checked[3]
                rebuildHome()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun accentIndex(): Int {
        val i = accents.indexOf(cfg.accent)
        return if (i >= 0) i else 0
    }

    private fun showSettings() {
        val shapeNames = listOf("Squircle", "Circle", "Rounded square")
        val sizeNames = listOf("Small", "Medium", "Large")
        val slideNames = listOf("Off", "Every hour", "Every day")
        val items = listOf(
            "Icon shape: " + shapeNames[cfg.shape],
            "Accent color: " + accentNames[accentIndex()],
            "Theme: " + (if (cfg.dark) "Dark" else "Light"),
            "Icon size: " + sizeNames[cfg.iconSize],
            "App labels: " + (if (cfg.labels) "On" else "Off"),
            "Wallpaper slideshow: " + slideNames[cfg.slideshow],
            "Home widgets",
            "City (weather & prayer): " + (if (cfg.city.isEmpty()) "not set" else cfg.city),
            "Double-tap to lock: " + (if (lockAdminActive()) "enabled" else "tap to enable"),
            "Hidden apps",
            "Change PIN",
            "About this launcher"
        )
        choose("Launcher settings", items) { which ->
            when (which) {
                0 -> {
                    cfg.shape = (cfg.shape + 1) % 3
                    applyTheme()
                    showSettings()
                }
                1 -> choose("Accent color", accentNames.toList()) { i ->
                    cfg.accent = accents[i]
                    applyTheme()
                    showSettings()
                }
                2 -> {
                    cfg.dark = !cfg.dark
                    applyTheme()
                    showSettings()
                }
                3 -> {
                    cfg.iconSize = (cfg.iconSize + 1) % 3
                    applyTheme()
                    showSettings()
                }
                4 -> {
                    cfg.labels = !cfg.labels
                    applyTheme()
                    showSettings()
                }
                5 -> {
                    cfg.slideshow = (cfg.slideshow + 1) % 3
                    cfg.lastSlide = System.currentTimeMillis()
                    showSettings()
                }
                6 -> showWidgetToggles()
                7 -> showLocationDialog()
                8 -> {
                    if (lockAdminActive()) {
                        toast("Already enabled. Double-tap the home screen to lock your phone.")
                    } else {
                        enableLockAdmin()
                    }
                }
                9 -> if (cfg.hasPin()) {
                    askPin("Enter PIN") { showHiddenApps() }
                } else {
                    toast("No PIN set yet. Hide or lock an app first.")
                }
                10 -> if (cfg.hasPin()) {
                    askPin("Current PIN") { setupPin { } }
                } else {
                    setupPin { }
                }
                11 -> showDevInfo()
            }
        }
    }

    // ------------------------------------------------------------ lock screen and notifications

    private fun adminComp(): ComponentName = ComponentName(this, LockAdminReceiver::class.java)

    private fun lockAdminActive(): Boolean {
        val d = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return d.isAdminActive(adminComp())
    }

    private fun enableLockAdmin() {
        val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
        i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComp())
        i.putExtra(
            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
            "This permission is only used to lock your phone when you double-tap the home screen."
        )
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast("Can't open settings")
        }
    }

    private fun lockScreen() {
        if (lockAdminActive()) {
            val d = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            d.lockNow()
        } else {
            toast("To lock with a double-tap, enable it in Settings > Double-tap to lock")
        }
    }

    private fun expandNotifications() {
        try {
            val sbs = getSystemService("statusbar")
            val m = Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel")
            m.invoke(sbs)
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------ drawer

    private fun openDrawer(focusSearch: Boolean) {
        if (drawerOpen) return
        drawerOpen = true
        if (drawerBg.drawable == null) {
            val dm = resources.displayMetrics
            drawerBg.setImageBitmap(decodeRes(builtinWp[2], dm.widthPixels / 2, dm.heightPixels / 2))
        }
        drawerRoot.alpha = 0f
        drawerRoot.translationY = dp(60).toFloat()
        drawerRoot.visibility = View.VISIBLE
        drawerRoot.animate().alpha(1f).translationY(0f).setDuration(220).start()
        if (focusSearch) {
            searchBox.requestFocus()
            handler.postDelayed({
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(searchBox, 0)
            }, 260)
        }
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        searchBox.setText("")
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(root.windowToken, 0)
        drawerRoot.animate().alpha(0f).translationY(dp(60).toFloat()).setDuration(180).withEndAction {
            drawerRoot.visibility = View.GONE
        }.start()
        grid.setSelection(0)
    }

    // ------------------------------------------------------------ quick chips, info screens, music

    private fun chip(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 12.5f
        t.typeface = Typeface.DEFAULT_BOLD
        t.setTextColor(fg())
        t.gravity = Gravity.CENTER
        t.maxLines = 1
        t.ellipsize = TextUtils.TruncateAt.END
        t.setPadding(dp(8), dp(10), dp(8), dp(10))
        t.background = roundBg(cardColor(), 16)
        t.setOnClickListener { onClick() }
        return t
    }

    private fun buildChipsRow(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(chip("👤 Hon. Musa") { showMusaInfo() }, lp(0, -2, 1f).apply { rightMargin = dp(4) })
        val m = chip("🎵 Music") { showMusicPlayer() }
        musicChip = m
        row.addView(m, lp(0, -2, 1f).apply {
            leftMargin = dp(4)
            rightMargin = dp(4)
        })
        row.addView(chip("💻 Developer") { showDevInfo() }, lp(0, -2, 1f).apply { leftMargin = dp(4) })
        updateMusicChip()
        return row
    }

    private fun updateMusicChip() {
        val c = musicChip ?: return
        val t = MusicPlayer.current()
        c.text = if (MusicPlayer.isPlaying() && t != null) "⏸ " + t.title else "🎵 Music"
    }

    private fun readSections(asset: String): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        try {
            val text = assets.open(asset).bufferedReader(Charsets.UTF_8).use { r -> r.readText() }
            var head = ""
            val sb = StringBuilder()
            for (line in text.lines()) {
                if (line.startsWith("## ")) {
                    if (head.isNotEmpty()) out.add(Pair(head, sb.toString().trim()))
                    head = line.substring(3).trim()
                    sb.setLength(0)
                } else {
                    val l = if (line.startsWith("- ")) "•  " + line.substring(2) else line
                    sb.append(l).append('\n')
                }
            }
            if (head.isNotEmpty()) out.add(Pair(head, sb.toString().trim()))
        } catch (e: Exception) {
        }
        return out
    }

    private fun showInfo(title: String, subtitle: String, imgIdx: Int, sections: List<Pair<String, String>>) {
        val d = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val frame = FrameLayout(this)
        frame.setBackgroundColor(Color.parseColor("#06101F"))
        val scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        val img = ImageView(this)
        if (imgIdx >= 0) {
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            img.setImageBitmap(decodeRes(campaignRes[imgIdx % campaignRes.size], dp(360), dp(330)))
            col.addView(img, lp(-1, dp(330)))
        } else {
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            img.setImageBitmap(decodeRes(R.drawable.dev, dp(360), dp(330)))
            col.addView(img, lp(-1, dp(330)))
        }

        val body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(dp(20), dp(16), dp(20), dp(40))

        val tt = TextView(this)
        tt.text = title
        tt.textSize = 26f
        tt.typeface = Typeface.DEFAULT_BOLD
        tt.setTextColor(Color.WHITE)
        body.addView(tt)

        val st = TextView(this)
        st.text = subtitle
        st.textSize = 14f
        st.setTextColor(cfg.accent)
        body.addView(st, lp(-2, -2).apply { topMargin = dp(2) })

        for (sec in sections) {
            val h = TextView(this)
            h.text = sec.first.uppercase()
            h.textSize = 12.5f
            h.typeface = Typeface.DEFAULT_BOLD
            h.setTextColor(cfg.accent)
            body.addView(h, lp(-2, -2).apply { topMargin = dp(20) })
            val tx = TextView(this)
            tx.text = sec.second
            tx.textSize = 15f
            tx.setTextColor(Color.argb(225, 255, 255, 255))
            tx.setLineSpacing(0f, 1.18f)
            body.addView(tx, lp(-1, -2).apply { topMargin = dp(6) })
        }
        col.addView(body, lp(-1, -2))
        scroll.addView(col)
        frame.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        val close = TextView(this)
        close.text = "✕"
        close.textSize = 20f
        close.setTextColor(Color.WHITE)
        close.gravity = Gravity.CENTER
        close.background = roundBg(Color.argb(150, 0, 0, 0), 22)
        close.setOnClickListener { d.dismiss() }
        frame.addView(close, FrameLayout.LayoutParams(dp(44), dp(44)).apply {
            gravity = Gravity.TOP or Gravity.END
            topMargin = dp(34)
            rightMargin = dp(16)
        })

        d.setContentView(frame)
        d.show()
    }

    private fun showMusaInfo() {
        var sections = readSections("about_musa.txt")
        if (sections.isEmpty()) {
            sections = listOf(Pair("Profile", "Hon. Musa Yusuf Drogba, House of Assembly candidate, Fika East Constituency, Yobe State."))
        }
        showInfo("Hon. Musa Yusuf Drogba", "House of Assembly • Fika East", 0, sections)
    }

    private fun showDevInfo() {
        var sections = readSections("about_dev.txt")
        if (sections.isEmpty()) {
            sections = listOf(Pair("Developer", "Abubakar Isah Yarima"))
        }
        showInfo("Musa Launcher", "Version 3.0", -1, sections)
    }

    // ---- music

    private fun startMusicService() {
        val i = Intent(this, MusicService::class.java)
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        } catch (e: Exception) {
        }
    }

    private fun fmtTime(ms: Int): String {
        val s = ms / 1000
        return (s / 60).toString() + ":" + (s % 60).toString().padStart(2, '0')
    }

    private fun pickSongs() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "audio/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        try {
            startActivityForResult(i, REQ_SONGS)
        } catch (e: Exception) {
            toast("Can't open the file picker")
        }
    }

    private fun nameOf(uri: Uri): String {
        var n = "Song"
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) n = c.getString(idx)
            }
        } catch (e: Exception) {
        }
        return n.substringBeforeLast('.')
    }

    private fun importSongs(data: Intent) {
        val uris = mutableListOf<Uri>()
        val cd = data.clipData
        if (cd != null) {
            for (k in 0 until cd.itemCount) uris.add(cd.getItemAt(k).uri)
        } else {
            val u = data.data
            if (u != null) uris.add(u)
        }
        val list = cfg.loadSongs()
        for (u in uris) {
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
            val s = u.toString()
            if (list.none { x -> x.first == s }) list.add(Pair(s, nameOf(u)))
        }
        cfg.saveSongs(list)
        MusicPlayer.init(this, list)
        MusicPlayer.changed()
        toast(uris.size.toString() + " song(s) added")
    }

    private fun confirmRemoveSong(t: Track) {
        val u = t.uri ?: return
        AlertDialog.Builder(this)
            .setTitle("Remove this song from the list?")
            .setPositiveButton("Remove") { _, _ ->
                val list = cfg.loadSongs()
                list.removeAll { x -> x.first == u }
                cfg.saveSongs(list)
                val cur = MusicPlayer.current()
                if (cur != null && cur.uri == u) MusicPlayer.stop()
                MusicPlayer.init(this, list)
                MusicPlayer.changed()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showMusicPlayer() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 5)
        }

        val d = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val rootV = LinearLayout(this)
        rootV.orientation = LinearLayout.VERTICAL
        rootV.setPadding(dp(20), dp(34), dp(20), dp(14))
        rootV.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#0B2A55"), Color.parseColor("#06101F"))
        )

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        val heading = TextView(this)
        heading.text = "Campaign Songs"
        heading.textSize = 18f
        heading.typeface = Typeface.DEFAULT_BOLD
        heading.setTextColor(Color.WHITE)
        bar.addView(heading, lp(0, -2, 1f))
        val x = TextView(this)
        x.text = "✕"
        x.textSize = 22f
        x.setTextColor(Color.WHITE)
        x.setPadding(dp(12), dp(4), dp(4), dp(4))
        x.setOnClickListener { d.dismiss() }
        bar.addView(x)
        rootV.addView(bar, lp(-1, -2))

        val cover = ImageView(this)
        cover.scaleType = ImageView.ScaleType.CENTER_CROP
        clipRound(cover, 22)
        rootV.addView(cover, lp(dp(200), dp(200)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = dp(14)
        })

        val title = TextView(this)
        title.textSize = 20f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(Color.WHITE)
        title.gravity = Gravity.CENTER
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        rootV.addView(title, lp(-1, -2).apply { topMargin = dp(14) })

        val sub = TextView(this)
        sub.textSize = 13f
        sub.setTextColor(Color.argb(185, 255, 255, 255))
        sub.gravity = Gravity.CENTER
        rootV.addView(sub, lp(-1, -2))

        val seek = SeekBar(this)
        rootV.addView(seek, lp(-1, -2).apply { topMargin = dp(10) })

        val times = LinearLayout(this)
        times.orientation = LinearLayout.HORIZONTAL
        val tCur = TextView(this)
        tCur.textSize = 12f
        tCur.setTextColor(Color.argb(185, 255, 255, 255))
        tCur.text = "0:00"
        val tTot = TextView(this)
        tTot.textSize = 12f
        tTot.setTextColor(Color.argb(185, 255, 255, 255))
        tTot.text = "0:00"
        times.addView(tCur, lp(0, -2, 1f))
        times.addView(tTot)
        rootV.addView(times, lp(-1, -2).apply {
            leftMargin = dp(6)
            rightMargin = dp(6)
        })

        fun ctl(label: String, size: Float, onClick: () -> Unit): TextView {
            val b = TextView(this)
            b.text = label
            b.textSize = size
            b.setTextColor(Color.WHITE)
            b.gravity = Gravity.CENTER
            b.setPadding(dp(14), dp(8), dp(14), dp(8))
            b.setOnClickListener { onClick() }
            return b
        }

        val btnShuffle = ctl("🔀", 22f) {
            MusicPlayer.shuffle = !MusicPlayer.shuffle
            MusicPlayer.changed()
        }
        val btnPrev = ctl("⏮", 28f) {
            startMusicService()
            MusicPlayer.prev()
        }
        val btnPlay = ctl("▶", 40f) {
            if (MusicPlayer.tracks.isEmpty()) {
                toast("Add songs first")
            } else {
                startMusicService()
                MusicPlayer.toggle()
            }
        }
        val btnNext = ctl("⏭", 28f) {
            startMusicService()
            MusicPlayer.next()
        }
        val btnRepeat = ctl("🔂", 22f) {
            MusicPlayer.repeatOne = !MusicPlayer.repeatOne
            MusicPlayer.changed()
        }
        val controls = LinearLayout(this)
        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER
        controls.addView(btnShuffle)
        controls.addView(btnPrev)
        controls.addView(btnPlay)
        controls.addView(btnNext)
        controls.addView(btnRepeat)
        rootV.addView(controls, lp(-1, -2).apply { topMargin = dp(4) })

        val listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(this)
        sv.addView(listBox)
        rootV.addView(sv, lp(-1, 0, 1f).apply { topMargin = dp(8) })

        val add = TextView(this)
        add.text = "＋  Add songs from phone"
        add.textSize = 14f
        add.typeface = Typeface.DEFAULT_BOLD
        add.setTextColor(Color.WHITE)
        add.gravity = Gravity.CENTER
        add.setPadding(dp(12), dp(12), dp(12), dp(12))
        add.background = roundBg(cfg.accent, 22)
        add.setOnClickListener { pickSongs() }
        rootV.addView(add, lp(-1, -2).apply { topMargin = dp(8) })

        fun refresh() {
            val t = MusicPlayer.current()
            title.text = if (t != null) t.title else "No songs yet"
            sub.text = if (MusicPlayer.tracks.isEmpty()) {
                "Add songs from your phone below"
            } else {
                "Track " + (MusicPlayer.index + 1) + " of " + MusicPlayer.tracks.size
            }
            btnPlay.text = if (MusicPlayer.isPlaying()) "⏸" else "▶"
            btnShuffle.alpha = if (MusicPlayer.shuffle) 1f else 0.4f
            btnRepeat.alpha = if (MusicPlayer.repeatOne) 1f else 0.4f
            cover.setImageBitmap(campaignBmp(MusicPlayer.index % 4))
            listBox.removeAllViews()
            for (i in MusicPlayer.tracks.indices) {
                val tr = MusicPlayer.tracks[i]
                val cur = i == MusicPlayer.index
                val row = TextView(this)
                val mark = if (cur && MusicPlayer.isPlaying()) "▶  " else (i + 1).toString() + ".  "
                row.text = mark + tr.title
                row.textSize = 15f
                row.setTextColor(if (cur) cfg.accent else Color.WHITE)
                row.setPadding(dp(14), dp(12), dp(14), dp(12))
                row.maxLines = 1
                row.ellipsize = TextUtils.TruncateAt.END
                if (cur) row.background = roundBg(Color.argb(40, 255, 255, 255), 12)
                row.setOnClickListener {
                    startMusicService()
                    MusicPlayer.play(i)
                }
                if (tr.uri != null) {
                    row.setOnLongClickListener {
                        confirmRemoveSong(tr)
                        true
                    }
                }
                listBox.addView(row, lp(-1, -2))
            }
        }

        var seeking = false
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) tCur.text = fmtTime(progress)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                seeking = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                seeking = false
                MusicPlayer.seek(seek.progress)
            }
        })

        val tick = object : Runnable {
            override fun run() {
                if (!seeking) {
                    val dur = MusicPlayer.duration()
                    seek.max = if (dur > 0) dur else 1
                    seek.progress = MusicPlayer.position()
                    tCur.text = fmtTime(MusicPlayer.position())
                    tTot.text = fmtTime(dur)
                }
                handler.postDelayed(this, 500)
            }
        }

        val listener: () -> Unit = { runOnUiThread { refresh() } }
        MusicPlayer.addListener(listener)
        d.setOnDismissListener {
            handler.removeCallbacks(tick)
            MusicPlayer.removeListener(listener)
        }

        refresh()
        handler.post(tick)
        d.setContentView(rootV)
        d.show()
    }


    // ------------------------------------------------------------ gestures

    private fun clickableAt(v: View, x: Float, y: Float): Boolean {
        if (v.visibility != View.VISIBLE) return false
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        if (x < loc[0] || x > loc[0] + v.width || y < loc[1] || y > loc[1] + v.height) return false
        if (v is ViewGroup) {
            for (i in v.childCount - 1 downTo 0) {
                if (clickableAt(v.getChildAt(i), x, y)) return true
            }
        }
        return v.isClickable || v.isLongClickable
    }

    private fun observeGesture(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gDownX = ev.rawX
                gDownY = ev.rawY
                gLong = false
                gEligible = !clickableAt(root, ev.rawX, ev.rawY)
                handler.removeCallbacks(longRunnable)
                if (gEligible) handler.postDelayed(longRunnable, 650)
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(ev.rawX - gDownX) > dp(12) || abs(ev.rawY - gDownY) > dp(12)) {
                    handler.removeCallbacks(longRunnable)
                }
            }
            MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longRunnable)
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longRunnable)
                if (gLong) return
                val dx = ev.rawX - gDownX
                val dy = ev.rawY - gDownY
                if (abs(dy) > dp(80) && abs(dy) > abs(dx) * 2) {
                    if (dy < 0) openDrawer(false) else expandNotifications()
                } else if (gEligible && abs(dx) < dp(12) && abs(dy) < dp(12)) {
                    val now = System.currentTimeMillis()
                    if (now - lastTapTime < 350) {
                        lastTapTime = 0L
                        lockScreen()
                    } else {
                        lastTapTime = now
                    }
                }
            }
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (!drawerOpen) observeGesture(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null && intent.action == Intent.ACTION_MAIN) {
            if (drawerOpen) closeDrawer() else pager.setCurrentItem(0, true)
        }
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (drawerOpen) {
            closeDrawer()
        } else if (pager.currentItem != 0) {
            pager.setCurrentItem(0, true)
        }
    }
}
