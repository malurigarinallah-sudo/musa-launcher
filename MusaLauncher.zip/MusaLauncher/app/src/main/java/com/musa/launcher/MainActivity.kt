package com.musa.launcher

import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.viewpager.widget.PagerAdapter
import androidx.viewpager.widget.ViewPager
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class AppItem(
    val label: String,
    val pkg: String,
    val activity: String,
    val icon: Drawable
)

class MainActivity : Activity() {

    companion object {
        const val REQ_PICK = 4711
    }

    private class Wp(val res: Int, val file: String?)

    private val builtinWp = intArrayOf(R.drawable.wp1, R.drawable.wp2, R.drawable.wp3, R.drawable.wp4)
    private val campaignRes = intArrayOf(R.drawable.cw1, R.drawable.cw2, R.drawable.cw3, R.drawable.cw4)
    private val campaignTags = arrayOf("Mafara Alkairi Ne", "Hope of the Peoples", "Fika East", "Mafara Alkairi Ne")
    private val campaignBmps = arrayOfNulls<Bitmap>(4)
    private var campaignIdx = 0

    private val accents = intArrayOf(
        Color.parseColor("#29B6F6"),
        Color.parseColor("#2ECC71"),
        Color.parseColor("#E53935"),
        Color.parseColor("#FFA726"),
        Color.parseColor("#EC407A"),
        Color.parseColor("#AB47BC")
    )
    private val accentNames = arrayOf("Shuɗi", "Kore", "Ja", "Lemu", "Ruwan hoda", "Shunayya")

    private val cols = 4
    private val perPage = 20

    private lateinit var cfg: Cfg
    private lateinit var homeList: MutableList<HomeEntry>

    private lateinit var root: FrameLayout
    private lateinit var wallpaperView: ImageView
    private lateinit var homeLayer: LinearLayout
    private lateinit var pager: ViewPager
    private lateinit var dots: LinearLayout
    private lateinit var dockRow: LinearLayout
    private lateinit var drawerRoot: FrameLayout
    private lateinit var drawerBg: ImageView
    private lateinit var drawerShade: View
    private lateinit var drawerLayer: LinearLayout
    private lateinit var searchBox: EditText
    private lateinit var gear: TextView
    private lateinit var grid: GridView
    private lateinit var adapter: AppAdapter

    private var allApps: List<AppItem> = emptyList()
    private var visibleApps: List<AppItem> = emptyList()
    private var drawerOpen = false
    private val handler = Handler(Looper.getMainLooper())

    // widget references (rebuilt with the widget page)
    private var batteryPct: TextView? = null
    private var batteryFill: View? = null
    private var batteryRest: View? = null
    private var weatherIcon: TextView? = null
    private var weatherTemp: TextView? = null
    private var weatherSub: TextView? = null
    private var prayerNext: TextView? = null
    private var prayerHijri: TextView? = null
    private var prayerRow: LinearLayout? = null
    private var campaignImg: ImageView? = null
    private var campaignTag: TextView? = null

    private var weatherBusy = false
    private var prayerBusy = false

    // gesture state
    private var gDownX = 0f
    private var gDownY = 0f
    private var gEligible = false
    private var gLong = false
    private var lastTapTime = 0L
    private val longRunnable = Runnable {
        gLong = true
        showHomeMenu()
    }

    private val ticker = object : Runnable {
        override fun run() {
            renderBattery()
            renderPrayer()
            maybeAdvanceWallpaper()
            maybeRefreshNet()
            handler.postDelayed(this, 30000)
        }
    }

    private val campaignTicker = object : Runnable {
        override fun run() {
            nextCampaign()
            handler.postDelayed(this, 4500)
        }
    }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshApps()
        }
    }

    // ------------------------------------------------------------ helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h, weight)

    private fun fg(): Int = if (cfg.dark) Color.WHITE else Color.parseColor("#14181F")

    private fun fgSoft(): Int =
        if (cfg.dark) Color.argb(185, 255, 255, 255) else Color.argb(185, 20, 24, 31)

    private fun cardColor(): Int =
        if (cfg.dark) Color.argb(125, 0, 0, 0) else Color.argb(190, 255, 255, 255)

    private fun roundBg(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun cornerFor(size: Int): Float {
        val f = when (cfg.shape) {
            1 -> 0.5f
            2 -> 0.12f
            else -> 0.24f
        }
        return size * f
    }

    private fun iconDp(): Int = when (cfg.iconSize) {
        0 -> 50
        2 -> 64
        else -> 56
    }

    private fun roundIcon(size: Int, d: Drawable): ImageView {
        val iv = ImageView(this)
        iv.setImageDrawable(d)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, cornerFor(view.width))
            }
        }
        iv.clipToOutline = true
        iv.layoutParams = LinearLayout.LayoutParams(size, size)
        return iv
    }

    private fun clipRound(v: View, radiusDp: Int) {
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(radiusDp).toFloat())
            }
        }
        v.clipToOutline = true
    }

    private fun choose(title: String, items: List<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(items.toTypedArray()) { _, which -> onPick(which) }
            .show()
    }

    private fun prompt(title: String, hint: String, initial: String, onOk: (String) -> Unit) {
        val et = EditText(this)
        et.hint = hint
        et.setText(initial)
        et.setSingleLine(true)
        val wrap = FrameLayout(this)
        wrap.setPadding(dp(20), dp(8), dp(20), 0)
        wrap.addView(et)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(wrap)
            .setPositiveButton("To") { _, _ -> onOk(et.text.toString()) }
            .setNegativeButton("Soke", null)
            .show()
    }

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)
        homeList = cfg.loadHome()

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        buildUi()
        applyWallpaper(cfg.wallpaper, false)
        refreshApps()
        applyTheme()

        val f = IntentFilter()
        f.addAction(Intent.ACTION_PACKAGE_ADDED)
        f.addAction(Intent.ACTION_PACKAGE_REMOVED)
        f.addAction(Intent.ACTION_PACKAGE_CHANGED)
        f.addDataScheme("package")
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(packageReceiver, f, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(packageReceiver, f)
        }
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(ticker)
        handler.removeCallbacks(campaignTicker)
        handler.post(ticker)
        handler.postDelayed(campaignTicker, 4500)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
        handler.removeCallbacks(campaignTicker)
        handler.removeCallbacks(longRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(packageReceiver)
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------ UI

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        wallpaperView = ImageView(this)
        wallpaperView.scaleType = ImageView.ScaleType.CENTER_CROP
        root.addView(wallpaperView, FrameLayout.LayoutParams(-1, -1))

        val shade = View(this)
        shade.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.argb(90, 0, 0, 0), Color.argb(0, 0, 0, 0), Color.argb(120, 0, 0, 0))
        )
        root.addView(shade, FrameLayout.LayoutParams(-1, -1))

        homeLayer = LinearLayout(this)
        homeLayer.orientation = LinearLayout.VERTICAL

        dots = LinearLayout(this)
        dots.orientation = LinearLayout.HORIZONTAL
        dots.gravity = Gravity.CENTER

        pager = ViewPager(this)
        pager.id = View.generateViewId()
        pager.adapter = HomePagerAdapter()
        pager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int) {}
            override fun onPageSelected(position: Int) {
                updateDots(position)
            }

            override fun onPageScrollStateChanged(state: Int) {}
        })
        homeLayer.addView(pager, lp(-1, 0, 1f))
        homeLayer.addView(dots, lp(-1, dp(18)))

        dockRow = LinearLayout(this)
        dockRow.orientation = LinearLayout.HORIZONTAL
        dockRow.gravity = Gravity.CENTER
        dockRow.setPadding(dp(14), dp(12), dp(14), dp(12))
        homeLayer.addView(
            dockRow,
            lp(-2, -2).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(14)
                topMargin = dp(4)
            }
        )
        root.addView(homeLayer, FrameLayout.LayoutParams(-1, -1))

        // ---- drawer
        drawerRoot = FrameLayout(this)
        drawerRoot.visibility = View.GONE

        drawerBg = ImageView(this)
        drawerBg.scaleType = ImageView.ScaleType.CENTER_CROP
        drawerRoot.addView(drawerBg, FrameLayout.LayoutParams(-1, -1))

        drawerShade = View(this)
        drawerRoot.addView(drawerShade, FrameLayout.LayoutParams(-1, -1))

        drawerLayer = LinearLayout(this)
        drawerLayer.orientation = LinearLayout.VERTICAL

        val handleBox = FrameLayout(this)
        val handleBar = View(this)
        handleBar.background = roundBg(Color.argb(150, 160, 160, 160), 3)
        handleBox.addView(
            handleBar,
            FrameLayout.LayoutParams(dp(44), dp(5)).apply { gravity = Gravity.CENTER }
        )
        var hy = 0f
        handleBox.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> hy = e.y
                MotionEvent.ACTION_UP -> if (e.y - hy > dp(30) || abs(e.y - hy) < dp(6)) closeDrawer()
            }
            true
        }
        drawerLayer.addView(handleBox, lp(-1, dp(36)))

        val searchRow = LinearLayout(this)
        searchRow.orientation = LinearLayout.HORIZONTAL
        searchRow.gravity = Gravity.CENTER_VERTICAL

        searchBox = EditText(this)
        searchBox.hint = "Bincika manhaja..."
        searchBox.textSize = 16f
        searchBox.setSingleLine(true)
        searchBox.inputType = InputType.TYPE_CLASS_TEXT
        searchBox.setPadding(dp(18), dp(10), dp(18), dp(10))
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterApps(s?.toString() ?: "")
            }
        })
        searchRow.addView(searchBox, lp(0, -2, 1f))

        gear = TextView(this)
        gear.text = "⚙"
        gear.textSize = 24f
        gear.gravity = Gravity.CENTER
        gear.setOnClickListener { showSettings() }
        searchRow.addView(gear, lp(dp(46), dp(46)))

        drawerLayer.addView(
            searchRow,
            lp(-1, -2).apply {
                leftMargin = dp(18)
                rightMargin = dp(10)
                bottomMargin = dp(8)
            }
        )

        grid = GridView(this)
        grid.numColumns = 4
        grid.verticalSpacing = dp(6)
        grid.selector = GradientDrawable().apply { setColor(Color.TRANSPARENT) }
        grid.setPadding(dp(6), dp(6), dp(6), dp(6))
        grid.clipToPadding = false
        adapter = AppAdapter(emptyList())
        grid.adapter = adapter
        grid.setOnItemClickListener { _, _, pos, _ -> launch(adapter.items[pos]) }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            showAppMenu(adapter.items[pos])
            true
        }
        drawerLayer.addView(grid, lp(-1, 0, 1f))

        drawerRoot.addView(drawerLayer, FrameLayout.LayoutParams(-1, -1))
        root.addView(drawerRoot, FrameLayout.LayoutParams(-1, -1))

        @Suppress("DEPRECATION")
        root.setOnApplyWindowInsetsListener { _, insets ->
            val top = insets.systemWindowInsetTop
            val bottom = insets.systemWindowInsetBottom
            homeLayer.setPadding(0, top, 0, bottom)
            drawerLayer.setPadding(0, top, 0, bottom)
            insets
        }

        setContentView(root)
    }

    private fun applyTheme() {
        drawerShade.setBackgroundColor(
            if (cfg.dark) Color.argb(205, 0, 0, 0) else Color.argb(222, 255, 255, 255)
        )
        searchBox.setTextColor(fg())
        searchBox.setHintTextColor(fgSoft())
        searchBox.background = roundBg(
            if (cfg.dark) Color.argb(70, 255, 255, 255) else Color.argb(50, 0, 0, 0), 22
        )
        gear.setTextColor(fg())
        adapter.notifyDataSetChanged()
        buildDock()
        rebuildHome()
    }

    // ------------------------------------------------------------ pager

    private fun pageCount(): Int {
        val appPages = maxOf(1, (homeList.size + perPage - 1) / perPage)
        return 1 + appPages
    }

    private inner class HomePagerAdapter : PagerAdapter() {
        override fun getCount(): Int = pageCount()

        override fun isViewFromObject(view: View, obj: Any): Boolean = view === obj

        override fun instantiateItem(container: ViewGroup, position: Int): Any {
            val v = if (position == 0) buildWidgetPage() else buildAppsPage(position - 1)
            container.addView(v)
            return v
        }

        override fun destroyItem(container: ViewGroup, position: Int, obj: Any) {
            container.removeView(obj as View)
        }

        override fun getItemPosition(obj: Any): Int = POSITION_NONE
    }

    private fun rebuildHome() {
        pager.adapter?.notifyDataSetChanged()
        updateDots(pager.currentItem)
    }

    private fun updateDots(sel: Int) {
        dots.removeAllViews()
        val n = pageCount()
        if (n <= 1) return
        for (i in 0 until n) {
            val d = View(this)
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(if (i == sel) Color.WHITE else Color.argb(110, 255, 255, 255))
            d.background = g
            val s = if (i == sel) 8 else 6
            dots.addView(d, lp(dp(s), dp(s)).apply {
                leftMargin = dp(3)
                rightMargin = dp(3)
            })
        }
    }

    // ------------------------------------------------------------ widget page

    private fun buildWidgetPage(): View {
        batteryPct = null
        batteryFill = null
        batteryRest = null
        weatherIcon = null
        weatherTemp = null
        weatherSub = null
        prayerNext = null
        prayerHijri = null
        prayerRow = null
        campaignImg = null
        campaignTag = null

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.gravity = Gravity.CENTER_HORIZONTAL
        page.setPadding(dp(16), dp(10), dp(16), dp(6))

        val clock = TextClock(this)
        clock.format12Hour = "h:mm"
        clock.format24Hour = "HH:mm"
        clock.textSize = 56f
        clock.setTextColor(Color.WHITE)
        clock.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        clock.setShadowLayer(10f, 0f, 2f, Color.argb(160, 0, 0, 0))
        page.addView(clock, lp(-2, -2))

        val date = TextClock(this)
        date.format12Hour = "EEEE, d MMMM"
        date.format24Hour = "EEEE, d MMMM"
        date.textSize = 15f
        date.setTextColor(Color.WHITE)
        date.setShadowLayer(8f, 0f, 2f, Color.argb(160, 0, 0, 0))
        page.addView(date, lp(-2, -2))

        val search = TextView(this)
        search.text = "🔍  Bincika manhajoji..."
        search.textSize = 15f
        search.setTextColor(fgSoft())
        search.setPadding(dp(18), dp(12), dp(18), dp(12))
        search.background = roundBg(cardColor(), 24)
        search.setOnClickListener { openDrawer(true) }
        page.addView(search, lp(-1, -2).apply {
            topMargin = dp(12)
            bottomMargin = dp(10)
        })

        if (cfg.showWeather || cfg.showBattery) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            if (cfg.showWeather) {
                row.addView(buildWeatherCard(), lp(0, -1, 1f).apply {
                    rightMargin = if (cfg.showBattery) dp(5) else 0
                })
            }
            if (cfg.showBattery) {
                row.addView(buildBatteryCard(), lp(0, -1, 1f).apply {
                    leftMargin = if (cfg.showWeather) dp(5) else 0
                })
            }
            page.addView(row, lp(-1, -2).apply { bottomMargin = dp(10) })
        }

        if (cfg.showPrayer) {
            page.addView(buildPrayerCard(), lp(-1, -2).apply { bottomMargin = dp(10) })
        }

        if (cfg.showCampaign) {
            val c = buildCampaignCard()
            c.minimumHeight = dp(110)
            page.addView(c, lp(-1, 0, 1f))
        } else {
            page.addView(View(this), lp(-1, 0, 1f))
        }

        renderBattery()
        renderWeather()
        renderPrayer()
        return page
    }

    private fun buildWeatherCard(): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(dp(12), dp(10), dp(12), dp(10))
        card.background = roundBg(cardColor(), 18)

        val ic = TextView(this)
        ic.textSize = 30f
        weatherIcon = ic
        card.addView(ic, lp(-2, -2).apply { rightMargin = dp(10) })

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val t = TextView(this)
        t.textSize = 22f
        t.setTextColor(fg())
        t.typeface = Typeface.DEFAULT_BOLD
        weatherTemp = t
        val c = TextView(this)
        c.textSize = 11f
        c.setTextColor(fgSoft())
        c.maxLines = 1
        c.ellipsize = TextUtils.TruncateAt.END
        weatherSub = c
        col.addView(t)
        col.addView(c)
        card.addView(col, lp(0, -2, 1f))

        card.setOnClickListener { showLocationDialog() }
        return card
    }

    private fun buildBatteryCard(): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.setPadding(dp(12), dp(10), dp(12), dp(10))
        card.background = roundBg(cardColor(), 18)

        val pct = TextView(this)
        pct.textSize = 22f
        pct.setTextColor(fg())
        pct.typeface = Typeface.DEFAULT_BOLD
        batteryPct = pct
        card.addView(pct)

        val sub = TextView(this)
        sub.text = "Baturi"
        sub.textSize = 11f
        sub.setTextColor(fgSoft())
        card.addView(sub)

        val track = LinearLayout(this)
        track.orientation = LinearLayout.HORIZONTAL
        track.background = roundBg(Color.argb(70, 128, 128, 128), 4)
        val fill = View(this)
        fill.background = roundBg(cfg.accent, 4)
        val rest = View(this)
        track.addView(fill, lp(0, dp(8), 50f))
        track.addView(rest, lp(0, dp(8), 50f))
        batteryFill = fill
        batteryRest = rest
        card.addView(track, lp(-1, dp(8)).apply { topMargin = dp(8) })
        return card
    }

    private fun buildPrayerCard(): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(12), dp(10), dp(12), dp(10))
        card.background = roundBg(cardColor(), 18)

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "🕌  Lokutan Sallah"
        title.textSize = 13f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(fg())
        head.addView(title, lp(0, -2, 1f))
        val hj = TextView(this)
        hj.textSize = 11f
        hj.setTextColor(fgSoft())
        prayerHijri = hj
        head.addView(hj)
        card.addView(head)

        val nx = TextView(this)
        nx.textSize = 12f
        nx.setTextColor(fgSoft())
        prayerNext = nx
        card.addView(nx, lp(-1, -2).apply {
            topMargin = dp(2)
            bottomMargin = dp(6)
        })

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        prayerRow = row
        card.addView(row, lp(-1, -2))

        card.setOnClickListener {
            if (cfg.city.isEmpty()) showLocationDialog()
        }
        return card
    }

    private fun buildCampaignCard(): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = roundBg(cardColor(), 18)
        clipRound(card, 18)

        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL
        left.gravity = Gravity.CENTER_VERTICAL
        left.setPadding(dp(16), dp(10), dp(8), dp(10))

        val tag = TextView(this)
        tag.textSize = 11f
        tag.typeface = Typeface.DEFAULT_BOLD
        tag.setTextColor(cfg.accent)
        tag.text = campaignTags[campaignIdx].uppercase()
        campaignTag = tag
        left.addView(tag)

        val hon = TextView(this)
        hon.text = "Hon."
        hon.textSize = 13f
        hon.setTextColor(fgSoft())
        left.addView(hon, lp(-2, -2).apply { topMargin = dp(4) })

        val n1 = TextView(this)
        n1.text = "Musa Yusuf"
        n1.textSize = 21f
        n1.typeface = Typeface.DEFAULT_BOLD
        n1.setTextColor(fg())
        left.addView(n1)

        val n2 = TextView(this)
        n2.text = "Drogba"
        n2.textSize = 21f
        n2.typeface = Typeface.DEFAULT_BOLD
        n2.setTextColor(cfg.accent)
        left.addView(n2)

        val sub = TextView(this)
        sub.text = "House of Assembly • Fika East"
        sub.textSize = 10.5f
        sub.setTextColor(fgSoft())
        sub.maxLines = 2
        left.addView(sub, lp(-2, -2).apply { topMargin = dp(4) })

        card.addView(left, lp(0, -1, 1f))

        val img = ImageView(this)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.setImageBitmap(campaignBmp(campaignIdx))
        campaignImg = img
        card.addView(img, lp(dp(130), -1))

        card.setOnClickListener { nextCampaign() }
        return card
    }

    private fun campaignBmp(i: Int): Bitmap? {
        val idx = if (i in campaignRes.indices) i else 0
        if (campaignBmps[idx] == null) {
            campaignBmps[idx] = decodeRes(campaignRes[idx], dp(160), dp(160))
        }
        return campaignBmps[idx]
    }

    private fun nextCampaign() {
        val img = campaignImg ?: return
        campaignIdx = (campaignIdx + 1) % campaignRes.size
        val bmp = campaignBmp(campaignIdx)
        img.animate().alpha(0f).setDuration(250).withEndAction {
            img.setImageBitmap(bmp)
            campaignTag?.text = campaignTags[campaignIdx].uppercase()
            img.animate().alpha(1f).setDuration(300).start()
        }.start()
    }

    // ------------------------------------------------------------ widget rendering

    private fun renderBattery() {
        val pctView = batteryPct ?: return
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING ||
            st == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        pctView.text = (if (charging) "⚡ " else "") + pct + "%"
        val f = batteryFill
        val r = batteryRest
        if (f != null && r != null) {
            (f.layoutParams as LinearLayout.LayoutParams).weight = pct.toFloat()
            (r.layoutParams as LinearLayout.LayoutParams).weight = (100 - pct).toFloat()
            f.requestLayout()
            r.requestLayout()
        }
    }

    private fun weatherIconFor(code: Int): String = when (code) {
        0 -> "☀️"
        1, 2 -> "🌤️"
        3 -> "☁️"
        45, 48 -> "🌫️"
        in 51..67 -> "🌧️"
        in 80..82 -> "🌧️"
        in 95..99 -> "⛈️"
        else -> "🌡️"
    }

    private fun weatherDescFor(code: Int): String = when (code) {
        0 -> "Sama a buɗe"
        1, 2 -> "Gajimare kaɗan"
        3 -> "Gajimare"
        45, 48 -> "Hazo"
        in 51..57 -> "Ɗan ruwa"
        in 61..67 -> "Ruwan sama"
        in 80..82 -> "Ruwan sama"
        in 95..99 -> "Tsawa"
        else -> ""
    }

    private fun renderWeather() {
        val ic = weatherIcon ?: return
        val t = weatherTemp ?: return
        val s = weatherSub ?: return
        if (cfg.city.isEmpty()) {
            ic.text = "🌤️"
            t.text = "--°"
            s.text = "Danna don saita gari"
            return
        }
        val parts = cfg.weatherCache.split("|")
        if (parts.size < 2) {
            ic.text = "🌤️"
            t.text = "--°"
            s.text = cfg.city
            return
        }
        val code = parts[1].toIntOrNull() ?: -1
        ic.text = weatherIconFor(code)
        t.text = parts[0] + "°C"
        val d = weatherDescFor(code)
        s.text = if (d.isEmpty()) cfg.city else cfg.city + " • " + d
    }

    private fun toMin(hhmm: String): Int {
        return try {
            val p = hhmm.trim().take(5).split(":")
            p[0].toInt() * 60 + p[1].toInt()
        } catch (e: Exception) {
            -1
        }
    }

    private fun renderPrayer() {
        val nx = prayerNext ?: return
        val row = prayerRow ?: return
        val hj = prayerHijri
        row.removeAllViews()
        if (cfg.city.isEmpty()) {
            nx.text = "Danna nan don saita garinka"
            hj?.text = ""
            return
        }
        val parts = cfg.prayerCache.split("|")
        if (parts.size < 6) {
            nx.text = "Ana lodawa..."
            hj?.text = ""
            return
        }
        hj?.text = parts[5]
        val names = listOf("Subhi", "Azahar", "La'asar", "Magariba", "Isha'i")
        val cal = Calendar.getInstance()
        val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        var next = -1
        for (i in 0 until 5) {
            val m = toMin(parts[i])
            if (m > nowMin) {
                next = i
                break
            }
        }
        if (next >= 0) {
            val diff = toMin(parts[next]) - nowMin
            val h = diff / 60
            val m = diff % 60
            val left = if (h > 0) h.toString() + "s " + m + "m" else m.toString() + "m"
            nx.text = "Na gaba: " + names[next] + " • " + parts[next].trim().take(5) + " (cikin " + left + ")"
        } else {
            nx.text = "Na gaba: Subhi gobe • " + parts[0].trim().take(5)
        }
        val hi = if (next >= 0) next else 0
        for (i in 0 until 5) {
            val cell = LinearLayout(this)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            val n = TextView(this)
            n.text = names[i]
            n.textSize = 10f
            n.setTextColor(fgSoft())
            n.gravity = Gravity.CENTER
            val tm = TextView(this)
            tm.text = parts[i].trim().take(5)
            tm.textSize = 13f
            tm.typeface = Typeface.DEFAULT_BOLD
            tm.setTextColor(if (i == hi) cfg.accent else fg())
            tm.gravity = Gravity.CENTER
            cell.addView(n)
            cell.addView(tm)
            row.addView(cell, lp(0, -2, 1f))
        }
    }

    // ------------------------------------------------------------ network (weather, prayer)

    private fun todayStr(): String = SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date())

    private fun maybeRefreshNet() {
        if (cfg.lat.isEmpty() || cfg.lon.isEmpty()) return
        if (System.currentTimeMillis() - cfg.weatherTime > 30 * 60 * 1000L) fetchWeather()
        if (cfg.prayerDate != todayStr()) fetchPrayer()
    }

    private fun parseWeather(s: String?): String? {
        if (s == null) return null
        return try {
            val cur = JSONObject(s).getJSONObject("current")
            Math.round(cur.getDouble("temperature_2m")).toString() + "|" + cur.getInt("weather_code")
        } catch (e: Exception) {
            null
        }
    }

    private fun fetchWeather() {
        if (weatherBusy) return
        weatherBusy = true
        val lat = cfg.lat
        val lon = cfg.lon
        Thread {
            val s = Net.get(
                "https://api.open-meteo.com/v1/forecast?latitude=" + lat + "&longitude=" + lon +
                    "&current=temperature_2m,weather_code&timezone=auto"
            )
            val ok = parseWeather(s)
            runOnUiThread {
                weatherBusy = false
                if (ok != null) {
                    cfg.weatherCache = ok
                    cfg.weatherTime = System.currentTimeMillis()
                    renderWeather()
                }
            }
        }.start()
    }

    private fun parsePrayer(s: String?): String? {
        if (s == null) return null
        return try {
            val data = JSONObject(s).getJSONObject("data")
            val t = data.getJSONObject("timings")
            val h = data.getJSONObject("date").getJSONObject("hijri")
            val hijri = h.getString("day") + " " + h.getJSONObject("month").getString("en") + " " + h.getString("year")
            listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
                .joinToString("|") { k -> t.getString(k).trim().take(5) } + "|" + hijri
        } catch (e: Exception) {
            null
        }
    }

    private fun fetchPrayer() {
        if (prayerBusy) return
        prayerBusy = true
        val lat = cfg.lat
        val lon = cfg.lon
        val date = todayStr()
        Thread {
            val s = Net.get(
                "https://api.aladhan.com/v1/timings/" + date + "?latitude=" + lat +
                    "&longitude=" + lon + "&method=3"
            )
            val ok = parsePrayer(s)
            runOnUiThread {
                prayerBusy = false
                if (ok != null) {
                    cfg.prayerCache = ok
                    cfg.prayerDate = date
                    renderPrayer()
                }
            }
        }.start()
    }

    private fun parseGeo(s: String?): String? {
        if (s == null) return null
        return try {
            val arr = JSONObject(s).optJSONArray("results") ?: return null
            val o = arr.getJSONObject(0)
            o.getString("name") + "|" + o.getDouble("latitude") + "|" + o.getDouble("longitude")
        } catch (e: Exception) {
            null
        }
    }

    private fun showLocationDialog() {
        prompt("Sunan garinka", "misali: Potiskum", cfg.city) { name ->
            val n = name.trim()
            if (n.isEmpty()) return@prompt
            toast("Ana nema...")
            Thread {
                val s = Net.get(
                    "https://geocoding-api.open-meteo.com/v1/search?name=" + Uri.encode(n) +
                        "&count=1&language=en&format=json"
                )
                val r = parseGeo(s)
                runOnUiThread {
                    if (r == null) {
                        toast("Ba a samu garin ba. Duba intanet ko rubutun suna.")
                    } else {
                        val p = r.split("|")
                        cfg.city = p[0]
                        cfg.lat = p[1]
                        cfg.lon = p[2]
                        cfg.weatherTime = 0L
                        cfg.weatherCache = ""
                        cfg.prayerDate = ""
                        cfg.prayerCache = ""
                        renderWeather()
                        renderPrayer()
                        maybeRefreshNet()
                        toast("An saita: " + p[0])
                    }
                }
            }.start()
        }
    }

    // ------------------------------------------------------------ wallpapers

    private fun sampleFor(w: Int, h: Int, reqW: Int, reqH: Int): Int {
        var sample = 1
        while (w / (sample * 2) >= reqW && h / (sample * 2) >= reqH) sample *= 2
        return sample
    }

    private fun decodeRes(resId: Int, reqW: Int, reqH: Int): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeResource(resources, resId, o)
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sampleFor(o.outWidth, o.outHeight, reqW, reqH)
        o2.inPreferredConfig = Bitmap.Config.RGB_565
        return BitmapFactory.decodeResource(resources, resId, o2)
    }

    private fun decodeFile(path: String, reqW: Int, reqH: Int): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(path, o)
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sampleFor(o.outWidth, o.outHeight, reqW, reqH)
        o2.inPreferredConfig = Bitmap.Config.RGB_565
        return BitmapFactory.decodeFile(path, o2)
    }

    private fun wallpapers(): List<Wp> {
        val l = mutableListOf<Wp>()
        for (r in builtinWp) l.add(Wp(r, null))
        for (f in cfg.customWps) {
            if (File(filesDir, f).exists()) l.add(Wp(0, f))
        }
        return l
    }

    private fun decodeWp(w: Wp, rw: Int, rh: Int): Bitmap? {
        val f = w.file
        return if (f != null) decodeFile(File(filesDir, f).absolutePath, rw, rh) else decodeRes(w.res, rw, rh)
    }

    private fun applyWallpaper(index: Int, animate: Boolean) {
        val list = wallpapers()
        val i = if (index in list.indices) index else 0
        cfg.wallpaper = i
        val dm = resources.displayMetrics
        val bmp = decodeWp(list[i], dm.widthPixels, dm.heightPixels)
        if (!animate) {
            wallpaperView.setImageBitmap(bmp)
            return
        }
        wallpaperView.animate().alpha(0f).setDuration(300).withEndAction {
            wallpaperView.setImageBitmap(bmp)
            wallpaperView.animate().alpha(1f).setDuration(400).start()
        }.start()
    }

    private fun maybeAdvanceWallpaper() {
        if (cfg.slideshow == 0) return
        val interval = if (cfg.slideshow == 1) 3600000L else 86400000L
        val now = System.currentTimeMillis()
        if (now - cfg.lastSlide < interval) return
        cfg.lastSlide = now
        applyWallpaper(cfg.wallpaper + 1, true)
    }

    private fun showWallpaperPicker() {
        val list = wallpapers()
        val holder = arrayOfNulls<AlertDialog>(1)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.setPadding(dp(12), dp(12), dp(12), dp(12))
        for (i in list.indices) {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setImageBitmap(decodeWp(list[i], dp(110), dp(190)))
            clipRound(iv, 14)
            iv.setOnClickListener {
                applyWallpaper(i, true)
                holder[0]?.dismiss()
            }
            if (list[i].file != null) {
                iv.setOnLongClickListener {
                    holder[0]?.dismiss()
                    confirmDeleteWallpaper(list[i])
                    true
                }
            }
            row.addView(iv, lp(dp(110), dp(190)).apply { rightMargin = dp(10) })
        }
        val plus = TextView(this)
        plus.text = "＋\nHoto daga\nwayarka"
        plus.textSize = 13f
        plus.gravity = Gravity.CENTER
        plus.setTextColor(Color.WHITE)
        plus.background = roundBg(Color.argb(90, 128, 128, 128), 14)
        plus.setOnClickListener {
            holder[0]?.dismiss()
            pickCustomWallpaper()
        }
        row.addView(plus, lp(dp(110), dp(190)))

        val scroll = HorizontalScrollView(this)
        scroll.addView(row)
        val d = AlertDialog.Builder(this)
            .setTitle("Zaɓi wallpaper")
            .setView(scroll)
            .setNegativeButton("Rufe", null)
            .create()
        holder[0] = d
        d.show()
    }

    private fun confirmDeleteWallpaper(w: Wp) {
        val f = w.file ?: return
        AlertDialog.Builder(this)
            .setTitle("Goge wannan hoton?")
            .setPositiveButton("Goge") { _, _ ->
                File(filesDir, f).delete()
                val l = cfg.customWps
                l.remove(f)
                cfg.customWps = l
                applyWallpaper(0, true)
            }
            .setNegativeButton("Soke", null)
            .show()
    }

    private fun pickCustomWallpaper() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        try {
            startActivityForResult(i, REQ_PICK)
        } catch (e: Exception) {
            toast("Ba a iya buɗe gallery ba")
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK) {
            val uri = data?.data
            if (uri != null) importWallpaper(uri)
        }
    }

    private fun importWallpaper(uri: Uri) {
        Thread {
            try {
                val dm = resources.displayMetrics
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                contentResolver.openInputStream(uri)?.use { s -> BitmapFactory.decodeStream(s, null, o) }
                o.inSampleSize = sampleFor(o.outWidth, o.outHeight, dm.widthPixels, dm.heightPixels)
                o.inJustDecodeBounds = false
                val bmp = contentResolver.openInputStream(uri)?.use { s -> BitmapFactory.decodeStream(s, null, o) }
                if (bmp != null) {
                    val name = "wpc_" + System.currentTimeMillis() + ".jpg"
                    FileOutputStream(File(filesDir, name)).use { out ->
                        bmp.compress(Bitmap.CompressFormat.JPEG, 88, out)
                    }
                    val l = cfg.customWps
                    l.add(name)
                    cfg.customWps = l
                    runOnUiThread {
                        applyWallpaper(wallpapers().size - 1, true)
                        toast("An saka hoton")
                    }
                } else {
                    runOnUiThread { toast("Ba a iya ɗaukar hoton ba") }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Ba a iya ɗaukar hoton ba") }
            }
        }.start()
    }

    // ------------------------------------------------------------ apps

    private fun appByPkg(pkg: String): AppItem? = allApps.firstOrNull { a -> a.pkg == pkg }

    private fun saveHome() {
        cfg.saveHome(homeList)
    }

    private fun refreshApps() {
        val pm = packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        allApps = pm.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                AppItem(
                    it.loadLabel(pm).toString(),
                    it.activityInfo.packageName,
                    it.activityInfo.name,
                    it.loadIcon(pm)
                )
            }
            .sortedBy { it.label.lowercase() }
        val hidden = cfg.hidden
        visibleApps = allApps.filter { a -> !hidden.contains(a.pkg) }

        if (allApps.isNotEmpty()) {
            var changed = false
            val iter = homeList.iterator()
            while (iter.hasNext()) {
                val e = iter.next()
                val before = e.pkgs.size
                e.pkgs.removeAll { p -> allApps.none { a -> a.pkg == p } }
                if (e.pkgs.size != before) changed = true
                if (e.pkgs.isEmpty()) {
                    iter.remove()
                    changed = true
                }
            }
            if (changed) saveHome()
        }

        filterApps(searchBox.text.toString())
        buildDock()
        rebuildHome()
    }

    private fun filterApps(q: String) {
        val t = q.trim()
        adapter.items = if (t.isEmpty()) visibleApps else visibleApps.filter { a -> a.label.contains(t, ignoreCase = true) }
        adapter.notifyDataSetChanged()
    }

    private fun launch(a: AppItem) {
        if (cfg.locked.contains(a.pkg)) {
            askPin("PIN na " + a.label) { launchNow(a) }
            return
        }
        launchNow(a)
    }

    private fun launchNow(a: AppItem) {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(a.pkg, a.activity)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast("Ba a iya buɗe manhajar ba")
        }
        if (drawerOpen) closeDrawer()
    }

    private inner class AppAdapter(var items: List<AppItem>) : BaseAdapter() {
        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Any = items[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val item = items[position]
            val cell = LinearLayout(this@MainActivity)
            cell.orientation = LinearLayout.VERTICAL
            cell.gravity = Gravity.CENTER_HORIZONTAL
            cell.setPadding(dp(2), dp(8), dp(2), dp(8))
            cell.addView(roundIcon(dp(iconDp()), item.icon))
            if (cfg.labels) {
                val tv = TextView(this@MainActivity)
                tv.text = item.label
                tv.setTextColor(fg())
                tv.textSize = 11.5f
                tv.maxLines = 1
                tv.gravity = Gravity.CENTER
                tv.ellipsize = TextUtils.TruncateAt.END
                cell.addView(tv, lp(-1, -2).apply { topMargin = dp(5) })
            }
            return cell
        }
    }

    // long-press menu in the drawer
    private fun showAppMenu(a: AppItem) {
        val isLocked = cfg.locked.contains(a.pkg)
        val opts = listOf(
            "Saka a allon gida",
            "Saka a dock",
            "Boye manhajar",
            if (isLocked) "Cire kulle (PIN)" else "Kulle da PIN",
            "Bayanin manhaja",
            "Cire manhajar (uninstall)"
        )
        choose(a.label, opts) { which ->
            when (which) {
                0 -> addToHome(a)
                1 -> pinToDock(a)
                2 -> ensurePin { hideApp(a) }
                3 -> if (isLocked) {
                    askPin("Cire kulle") { unlockApp(a) }
                } else {
                    ensurePin { lockApp(a) }
                }
                4 -> {
                    val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.pkg))
                    try {
                        startActivity(i)
                    } catch (e: Exception) {
                    }
                }
                5 -> {
                    val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg))
                    try {
                        startActivity(i)
                    } catch (e: Exception) {
                        toast("Ba a iya cire manhajar ba")
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ home screen apps and folders

    private fun makeCell(icon: View, label: String): LinearLayout {
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.VERTICAL
        cell.gravity = Gravity.CENTER_HORIZONTAL
        cell.setPadding(dp(2), dp(8), dp(2), dp(8))
        cell.addView(icon)
        if (cfg.labels) {
            val tv = TextView(this)
            tv.text = label
            tv.setTextColor(Color.WHITE)
            tv.textSize = 11.5f
            tv.maxLines = 1
            tv.gravity = Gravity.CENTER
            tv.ellipsize = TextUtils.TruncateAt.END
            tv.setShadowLayer(4f, 0f, 1f, Color.BLACK)
            cell.addView(tv, lp(-1, -2).apply { topMargin = dp(5) })
        }
        return cell
    }

    private fun folderIcon(e: HomeEntry, size: Int): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.setColor(Color.argb(120, 255, 255, 255))
        g.cornerRadius = cornerFor(size)
        box.background = g
        val mini = size * 38 / 100
        val apps = e.pkgs.mapNotNull { p -> appByPkg(p) }.take(4)
        for (r in 0..1) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (c in 0..1) {
                val a = apps.getOrNull(r * 2 + c)
                val v: View = if (a != null) {
                    val iv = ImageView(this)
                    iv.setImageDrawable(a.icon)
                    iv.scaleType = ImageView.ScaleType.FIT_CENTER
                    iv
                } else {
                    View(this)
                }
                row.addView(v, lp(mini, mini).apply {
                    leftMargin = dp(1)
                    rightMargin = dp(1)
                    topMargin = dp(1)
                    bottomMargin = dp(1)
                })
            }
            box.addView(row)
        }
        box.layoutParams = LinearLayout.LayoutParams(size, size)
        return box
    }

    private fun entryCell(e: HomeEntry): View? {
        val size = dp(iconDp())
        val folderName = e.folder
        if (folderName != null) {
            val cell = makeCell(folderIcon(e, size), folderName)
            cell.setOnClickListener { openFolder(e) }
            cell.setOnLongClickListener {
                folderMenu(e)
                true
            }
            return cell
        }
        val app = appByPkg(e.pkgs.firstOrNull() ?: "") ?: return null
        val cell = makeCell(roundIcon(size, app.icon), app.label)
        cell.setOnClickListener { launch(app) }
        cell.setOnLongClickListener {
            homeAppMenu(e, app)
            true
        }
        return cell
    }

    private fun buildAppsPage(pageIdx: Int): View {
        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        page.setPadding(dp(8), dp(28), dp(8), dp(8))
        val entries = homeList.drop(pageIdx * perPage).take(perPage)
        if (entries.isEmpty() && pageIdx == 0) {
            val hint = TextView(this)
            hint.text = "Babu komai a nan tukuna.\n\nJa sama don buɗe jerin manhajoji, ka danna ka riƙe manhaja, sannan ka zaɓi \"Saka a allon gida\"."
            hint.setTextColor(Color.WHITE)
            hint.textSize = 14f
            hint.gravity = Gravity.CENTER
            hint.setShadowLayer(6f, 0f, 1f, Color.BLACK)
            hint.setPadding(dp(24), dp(80), dp(24), 0)
            page.addView(hint, lp(-1, -2))
            return page
        }
        var row: LinearLayout? = null
        var inRow = 0
        for (e in entries) {
            val cell = entryCell(e) ?: continue
            if (row == null || inRow == cols) {
                row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                page.addView(row, lp(-1, -2))
                inRow = 0
            }
            row.addView(cell, lp(0, -2, 1f))
            inRow++
        }
        if (row != null) {
            while (inRow < cols) {
                row.addView(View(this), lp(0, 1, 1f))
                inRow++
            }
        }
        return page
    }

    private fun addToHome(a: AppItem) {
        val exists = homeList.any { e -> e.pkgs.contains(a.pkg) }
        if (exists) {
            toast("Tuni yana allon gida")
            return
        }
        homeList.add(HomeEntry(null, mutableListOf(a.pkg)))
        saveHome()
        rebuildHome()
        toast("An saka " + a.label + " a allon gida")
    }

    private fun homeAppMenu(e: HomeEntry, app: AppItem) {
        choose(app.label, listOf("Cire daga allon gida", "Saka cikin folder")) { which ->
            when (which) {
                0 -> {
                    homeList.remove(e)
                    saveHome()
                    rebuildHome()
                }
                1 -> addToFolderFlow(e)
            }
        }
    }

    private fun addToFolderFlow(e: HomeEntry) {
        val folders = homeList.filter { f -> f.folder != null }
        val names = mutableListOf("＋ Sabon folder")
        for (f in folders) names.add(f.folder ?: "Folder")
        choose("Saka cikin folder", names) { which ->
            if (which == 0) {
                prompt("Sunan folder", "misali: Social", "") { name ->
                    val n = if (name.isBlank()) "Folder" else name.trim()
                    val idx = homeList.indexOf(e)
                    if (idx >= 0) {
                        homeList[idx] = HomeEntry(n, mutableListOf(e.pkgs[0]))
                        saveHome()
                        rebuildHome()
                    }
                }
            } else {
                val f = folders[which - 1]
                val p = e.pkgs[0]
                if (!f.pkgs.contains(p)) f.pkgs.add(p)
                homeList.remove(e)
                saveHome()
                rebuildHome()
            }
        }
    }

    private fun folderMenu(f: HomeEntry) {
        choose(f.folder ?: "Folder", listOf("Buɗe", "Sake suna", "Rushe folder", "Cire folder")) { which ->
            when (which) {
                0 -> openFolder(f)
                1 -> prompt("Sabon suna", "Sunan folder", f.folder ?: "") { name ->
                    if (name.isNotBlank()) {
                        f.folder = name.trim()
                        saveHome()
                        rebuildHome()
                    }
                }
                2 -> {
                    val idx = homeList.indexOf(f)
                    if (idx >= 0) {
                        homeList.removeAt(idx)
                        homeList.addAll(idx, f.pkgs.map { p -> HomeEntry(null, mutableListOf(p)) })
                        saveHome()
                        rebuildHome()
                    }
                }
                3 -> {
                    homeList.remove(f)
                    saveHome()
                    rebuildHome()
                }
            }
        }
    }

    private fun openFolder(f: HomeEntry) {
        val apps = f.pkgs.mapNotNull { p -> appByPkg(p) }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(8), dp(8), dp(8), dp(8))
        val d = AlertDialog.Builder(this)
            .setTitle(f.folder ?: "Folder")
            .setView(box)
            .setNegativeButton("Rufe", null)
            .create()
        var row: LinearLayout? = null
        var inRow = 0
        for (a in apps) {
            val cell = makeCell(roundIcon(dp(iconDp()), a.icon), a.label)
            cell.setOnClickListener {
                d.dismiss()
                launch(a)
            }
            cell.setOnLongClickListener {
                f.pkgs.remove(a.pkg)
                if (f.pkgs.isEmpty()) homeList.remove(f)
                saveHome()
                rebuildHome()
                d.dismiss()
                toast("An cire " + a.label + " daga folder")
                true
            }
            if (row == null || inRow == cols) {
                row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                box.addView(row, lp(-1, -2))
                inRow = 0
            }
            row.addView(cell, lp(0, -2, 1f))
            inRow++
        }
        if (row != null) {
            while (inRow < cols) {
                row.addView(View(this), lp(0, 1, 1f))
                inRow++
            }
        }
        d.show()
    }

    // ------------------------------------------------------------ dock

    private fun defaultDock(): List<AppItem> {
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("http://example.com")),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val result = mutableListOf<AppItem>()
        for (intent in intents) {
            val ri = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY) ?: continue
            val pkg = ri.activityInfo.packageName
            val app = visibleApps.firstOrNull { a -> a.pkg == pkg } ?: continue
            if (result.none { r -> r.pkg == app.pkg }) result.add(app)
        }
        return result
    }

    private fun dockApps(): List<AppItem> {
        val saved = cfg.dock
        val list = saved.mapNotNull { pkg -> visibleApps.firstOrNull { a -> a.pkg == pkg } }
        if (list.isNotEmpty()) return list
        return defaultDock()
    }

    private fun buildDock() {
        dockRow.background = roundBg(
            if (cfg.dark) Color.argb(85, 255, 255, 255) else Color.argb(150, 255, 255, 255), 30
        )
        dockRow.removeAllViews()
        for (a in dockApps()) {
            val size = dp(iconDp() + 2)
            val iv = roundIcon(size, a.icon)
            iv.setOnClickListener { launch(a) }
            iv.setOnLongClickListener {
                unpinFromDock(a)
                true
            }
            val l = LinearLayout.LayoutParams(size, size)
            l.leftMargin = dp(8)
            l.rightMargin = dp(8)
            dockRow.addView(iv, l)
        }
    }

    private fun pinToDock(a: AppItem) {
        val cur = dockApps().map { x -> x.pkg }.toMutableList()
        if (cur.contains(a.pkg)) {
            toast("Tuni yana cikin dock")
            return
        }
        cur.add(a.pkg)
        while (cur.size > 4) cur.removeAt(0)
        cfg.dock = cur
        buildDock()
        toast("An saka " + a.label + " a dock")
    }

    private fun unpinFromDock(a: AppItem) {
        val cur = dockApps().map { x -> x.pkg }.toMutableList()
        cur.remove(a.pkg)
        cfg.dock = cur
        buildDock()
    }

    // ------------------------------------------------------------ PIN, hidden and locked apps

    private fun askPin(title: String, onOk: () -> Unit) {
        val et = EditText(this)
        et.hint = "PIN"
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        val wrap = FrameLayout(this)
        wrap.setPadding(dp(20), dp(8), dp(20), 0)
        wrap.addView(et)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(wrap)
            .setPositiveButton("To") { _, _ ->
                if (cfg.checkPin(et.text.toString())) onOk() else toast("PIN ba daidai ba")
            }
            .setNegativeButton("Soke", null)
            .show()
    }

    private fun setupPin(onDone: () -> Unit) {
        val a = EditText(this)
        a.hint = "Sabon PIN (lamba 4 ko fiye)"
        a.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        val b = EditText(this)
        b.hint = "Maimaita PIN"
        b.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.setPadding(dp(20), dp(8), dp(20), 0)
        wrap.addView(a)
        wrap.addView(b)
        AlertDialog.Builder(this)
            .setTitle("Saita PIN")
            .setView(wrap)
            .setPositiveButton("To") { _, _ ->
                val p1 = a.text.toString()
                val p2 = b.text.toString()
                if (p1.length < 4) {
                    toast("PIN ya gajarta (akalla lamba 4)")
                } else if (p1 != p2) {
                    toast("PIN ɗin biyu ba ɗaya suke ba")
                } else {
                    cfg.setPin(p1)
                    toast("An saita PIN")
                    onDone()
                }
            }
            .setNegativeButton("Soke", null)
            .show()
    }

    private fun ensurePin(then: () -> Unit) {
        if (cfg.hasPin()) then() else setupPin(then)
    }

    private fun hideApp(a: AppItem) {
        val h = cfg.hidden
        if (!h.contains(a.pkg)) h.add(a.pkg)
        cfg.hidden = h
        val d = cfg.dock
        d.remove(a.pkg)
        cfg.dock = d
        for (e in homeList) e.pkgs.remove(a.pkg)
        homeList.removeAll { e -> e.pkgs.isEmpty() }
        saveHome()
        refreshApps()
        toast("An boye " + a.label + ". Za ka same ta a Saituna > Manhajoji boyayyu")
    }

    private fun lockApp(a: AppItem) {
        val l = cfg.locked
        if (!l.contains(a.pkg)) l.add(a.pkg)
        cfg.locked = l
        toast(a.label + " yanzu yana buƙatar PIN daga launcher")
    }

    private fun unlockApp(a: AppItem) {
        val l = cfg.locked
        l.remove(a.pkg)
        cfg.locked = l
        toast("An cire kulle")
    }

    private fun showHiddenApps() {
        val hidden = cfg.hidden
        val list = allApps.filter { a -> hidden.contains(a.pkg) }
        if (list.isEmpty()) {
            toast("Babu manhajar da aka boye")
            return
        }
        choose("Manhajoji boyayyu", list.map { a -> a.label }) { idx ->
            val a = list[idx]
            choose(a.label, listOf("Buɗe", "Dawo da ita (unhide)")) { which ->
                when (which) {
                    0 -> launchNow(a)
                    1 -> {
                        val h = cfg.hidden
                        h.remove(a.pkg)
                        cfg.hidden = h
                        refreshApps()
                        toast("An dawo da " + a.label)
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------ menus and settings

    private fun showHomeMenu() {
        choose("Musa Launcher", listOf("Canza wallpaper", "Widgets", "Saitunan launcher")) { which ->
            when (which) {
                0 -> showWallpaperPicker()
                1 -> showWidgetToggles()
                2 -> showSettings()
            }
        }
    }

    private fun showWidgetToggles() {
        val names = arrayOf("Yanayi", "Lokutan sallah", "Baturi", "Widget na kamfen")
        val checked = booleanArrayOf(cfg.showWeather, cfg.showPrayer, cfg.showBattery, cfg.showCampaign)
        AlertDialog.Builder(this)
            .setTitle("Widgets")
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("To") { _, _ ->
                cfg.showWeather = checked[0]
                cfg.showPrayer = checked[1]
                cfg.showBattery = checked[2]
                cfg.showCampaign = checked[3]
                rebuildHome()
            }
            .setNegativeButton("Soke", null)
            .show()
    }

    private fun accentIndex(): Int {
        val i = accents.indexOf(cfg.accent)
        return if (i >= 0) i else 0
    }

    private fun showSettings() {
        val shapeNames = listOf("Squircle", "Zagaye", "Murabba'i mai lanƙwasa")
        val sizeNames = listOf("Ƙarami", "Matsakaici", "Babba")
        val slideNames = listOf("A kashe", "Kowane awa", "Kowace rana")
        val items = listOf(
            "Siffar icon: " + shapeNames[cfg.shape],
            "Launin accent: " + accentNames[accentIndex()],
            "Jigo: " + (if (cfg.dark) "Duhu" else "Haske"),
            "Girman icon: " + sizeNames[cfg.iconSize],
            "Sunayen manhajoji: " + (if (cfg.labels) "A kunne" else "A kashe"),
            "Wallpaper slideshow: " + slideNames[cfg.slideshow],
            "Widgets na allon gida",
            "Gari (yanayi da sallah): " + (if (cfg.city.isEmpty()) "ba a saita ba" else cfg.city),
            "Kulle waya da taɓa sau biyu: " + (if (lockAdminActive()) "an kunna" else "a kunna"),
            "Manhajoji boyayyu",
            "Canza PIN",
            "Game da launcher"
        )
        choose("Saitunan launcher", items) { which ->
            when (which) {
                0 -> {
                    cfg.shape = (cfg.shape + 1) % 3
                    applyTheme()
                    showSettings()
                }
                1 -> choose("Launin accent", accentNames.toList()) { i ->
                    cfg.accent = accents[i]
                    applyTheme()
                    showSettings()
                }
                2 -> {
                    cfg.dark = !cfg.dark
                    applyTheme()
                    showSettings()
                }
                3 -> {
                    cfg.iconSize = (cfg.iconSize + 1) % 3
                    applyTheme()
                    showSettings()
                }
                4 -> {
                    cfg.labels = !cfg.labels
                    applyTheme()
                    showSettings()
                }
                5 -> {
                    cfg.slideshow = (cfg.slideshow + 1) % 3
                    cfg.lastSlide = System.currentTimeMillis()
                    showSettings()
                }
                6 -> showWidgetToggles()
                7 -> showLocationDialog()
                8 -> {
                    if (lockAdminActive()) {
                        toast("Ya riga ya kunna. Taɓa sau biyu a allon gida don kulle waya.")
                    } else {
                        enableLockAdmin()
                    }
                }
                9 -> if (cfg.hasPin()) {
                    askPin("Shigar da PIN") { showHiddenApps() }
                } else {
                    toast("Ba ka saita PIN ba tukuna. Boye manhaja da farko.")
                }
                10 -> if (cfg.hasPin()) {
                    askPin("PIN na yanzu") { setupPin { } }
                } else {
                    setupPin { }
                }
                11 -> AlertDialog.Builder(this)
                    .setTitle("Musa Launcher 2.0")
                    .setMessage("Launcher mai shafuka, folders, widgets, boye manhajoji da kulle da PIN.")
                    .setPositiveButton("To", null)
                    .show()
            }
        }
    }

    // ------------------------------------------------------------ lock screen and notifications

    private fun adminComp(): ComponentName = ComponentName(this, LockAdminReceiver::class.java)

    private fun lockAdminActive(): Boolean {
        val d = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        return d.isAdminActive(adminComp())
    }

    private fun enableLockAdmin() {
        val i = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
        i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComp())
        i.putExtra(
            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
            "Ana buƙatar wannan izini ne kawai don kulle wayar idan ka taɓa allon gida sau biyu."
        )
        try {
            startActivity(i)
        } catch (e: Exception) {
            toast("Ba a iya buɗe saitin ba")
        }
    }

    private fun lockScreen() {
        if (lockAdminActive()) {
            val d = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            d.lockNow()
        } else {
            toast("Don kulle waya da taɓa sau biyu: Saituna > Kulle waya")
        }
    }

    private fun expandNotifications() {
        try {
            val sbs = getSystemService("statusbar")
            val m = Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel")
            m.invoke(sbs)
        } catch (e: Exception) {
        }
    }

    // ------------------------------------------------------------ drawer

    private fun openDrawer(focusSearch: Boolean) {
        if (drawerOpen) return
        drawerOpen = true
        if (drawerBg.drawable == null) {
            val dm = resources.displayMetrics
            drawerBg.setImageBitmap(decodeRes(builtinWp[2], dm.widthPixels / 2, dm.heightPixels / 2))
        }
        drawerRoot.alpha = 0f
        drawerRoot.translationY = dp(60).toFloat()
        drawerRoot.visibility = View.VISIBLE
        drawerRoot.animate().alpha(1f).translationY(0f).setDuration(220).start()
        if (focusSearch) {
            searchBox.requestFocus()
            handler.postDelayed({
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(searchBox, 0)
            }, 260)
        }
    }

    private fun closeDrawer() {
        if (!drawerOpen) return
        drawerOpen = false
        searchBox.setText("")
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(root.windowToken, 0)
        drawerRoot.animate().alpha(0f).translationY(dp(60).toFloat()).setDuration(180).withEndAction {
            drawerRoot.visibility = View.GONE
        }.start()
        grid.setSelection(0)
    }

    // ------------------------------------------------------------ gestures

    private fun clickableAt(v: View, x: Float, y: Float): Boolean {
        if (v.visibility != View.VISIBLE) return false
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        if (x < loc[0] || x > loc[0] + v.width || y < loc[1] || y > loc[1] + v.height) return false
        if (v is ViewGroup) {
            for (i in v.childCount - 1 downTo 0) {
                if (clickableAt(v.getChildAt(i), x, y)) return true
            }
        }
        return v.isClickable || v.isLongClickable
    }

    private fun observeGesture(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gDownX = ev.rawX
                gDownY = ev.rawY
                gLong = false
                gEligible = !clickableAt(root, ev.rawX, ev.rawY)
                handler.removeCallbacks(longRunnable)
                if (gEligible) handler.postDelayed(longRunnable, 650)
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(ev.rawX - gDownX) > dp(12) || abs(ev.rawY - gDownY) > dp(12)) {
                    handler.removeCallbacks(longRunnable)
                }
            }
            MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(longRunnable)
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longRunnable)
                if (gLong) return
                val dx = ev.rawX - gDownX
                val dy = ev.rawY - gDownY
                if (abs(dy) > dp(80) && abs(dy) > abs(dx) * 2) {
                    if (dy < 0) openDrawer(false) else expandNotifications()
                } else if (gEligible && abs(dx) < dp(12) && abs(dy) < dp(12)) {
                    val now = System.currentTimeMillis()
                    if (now - lastTapTime < 350) {
                        lastTapTime = 0L
                        lockScreen()
                    } else {
                        lastTapTime = now
                    }
                }
            }
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (!drawerOpen) observeGesture(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent != null && intent.action == Intent.ACTION_MAIN) {
            if (drawerOpen) closeDrawer() else pager.setCurrentItem(0, true)
        }
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (drawerOpen) {
            closeDrawer()
        } else if (pager.currentItem != 0) {
            pager.setCurrentItem(0, true)
        }
    }
}
