package com.musa.launcher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder

class MusicService : Service() {

    companion object {
        const val CH = "musa_music"
        const val NID = 77
        const val A_TOGGLE = "com.musa.launcher.TOGGLE"
        const val A_NEXT = "com.musa.launcher.NEXT"
        const val A_PREV = "com.musa.launcher.PREV"
        const val A_STOP = "com.musa.launcher.STOP"
    }

    private val listener: () -> Unit = { update() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH, "Music", NotificationManager.IMPORTANCE_LOW)
            )
        }
        MusicPlayer.addListener(listener)
    }

    override fun onDestroy() {
        MusicPlayer.removeListener(listener)
        super.onDestroy()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val act = intent?.action
        if (act == A_STOP) {
            MusicPlayer.stop()
            stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }
        goForeground()
        if (act == A_TOGGLE) MusicPlayer.toggle()
        if (act == A_NEXT) MusicPlayer.next()
        if (act == A_PREV) MusicPlayer.prev()
        return START_NOT_STICKY
    }

    private fun goForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NID, n)
        }
    }

    private fun update() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NID, buildNotification())
    }

    private fun act(icon: Int, label: String, action: String, code: Int): Notification.Action {
        val i = Intent(this, MusicService::class.java)
        i.action = action
        val pi = PendingIntent.getService(
            this, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Action.Builder(Icon.createWithResource(this, icon), label, pi).build()
    }

    private fun buildNotification(): Notification {
        val t = MusicPlayer.current()
        val playing = MusicPlayer.isPlaying()
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH) else Notification.Builder(this)
        b.setSmallIcon(android.R.drawable.ic_media_play)
        b.setContentTitle(if (t != null) t.title else "Musa Launcher")
        b.setContentText("Campaign songs")
        b.setOngoing(playing)
        b.setOnlyAlertOnce(true)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        b.setContentIntent(open)
        b.addAction(act(android.R.drawable.ic_media_previous, "Previous", A_PREV, 1))
        b.addAction(
            act(
                if (playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (playing) "Pause" else "Play", A_TOGGLE, 2
            )
        )
        b.addAction(act(android.R.drawable.ic_media_next, "Next", A_NEXT, 3))
        b.addAction(act(android.R.drawable.ic_menu_close_clear_cancel, "Stop", A_STOP, 4))
        b.setStyle(Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2))
        return b.build()
    }
}
